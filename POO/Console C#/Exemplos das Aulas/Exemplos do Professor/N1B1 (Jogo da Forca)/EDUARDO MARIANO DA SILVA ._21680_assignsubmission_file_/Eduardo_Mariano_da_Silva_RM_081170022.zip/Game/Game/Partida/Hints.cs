﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game.Partida
{
    public class Hints
    {
        public string text = "";
        public bool visible;
    }
}
