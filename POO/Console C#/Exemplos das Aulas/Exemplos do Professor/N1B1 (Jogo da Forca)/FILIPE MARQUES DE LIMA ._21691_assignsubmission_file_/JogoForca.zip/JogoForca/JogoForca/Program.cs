﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace MyForca
{
    class Program
    {
        struct StructPalavra
        {
            public string palavra;
            public string[] dicas;
            public int contadorDicas;
            public bool blank;
        }

        static void Main(string[] args)
        {
            bool encontrado = false;
            int x = 0;
            int qntd = 0;

            telaInicial();
            telaAbreJogo();

            StructPalavra[] palavras = new StructPalavra[100];

            trabalhaArquivo(palavras, ref encontrado, ref x, ref qntd);

            arrumadicas(palavras);

            int rodada = 0;
            int[] sorteiapalavra = new int[100];
            bool resposta;

            do
            {
                int escolhida;

                escolhida = Program.sorteiapalavra(sorteiapalavra, rodada, qntd);

                escreveLacuna(palavras[escolhida].palavra);

                int vidas = 10;
                int erros = 0;
                char[] usados = new char[palavras[escolhida].palavra.Length];


                forca(vidas, palavras, escolhida, usados, erros);

                resposta = newgame();
                rodada++;
                Console.Clear();
            }
            while (resposta == true);
            Thread.Sleep(100);
        }

        //este método lê o arquivo texto e guarda seu conteúdo.
        static void trabalhaArquivo(StructPalavra[] palavras, ref bool encontrado, ref int x, ref int qntd)
        {
            do
            {
                if (File.Exists("jogo.txt"))
                {
                    encontrado = true;
                    string[] texto = File.ReadAllLines("jogo.txt", Encoding.Default);
                    for (int n = 0; n < texto.Length; n++)
                    {
                        if (texto[n].ToUpper()[0] == 'P')
                        {
                            palavras[qntd] = new StructPalavra();
                            palavras[qntd].dicas = new string[11];
                            palavras[qntd].palavra = texto[n].Remove(0, 2).Trim();
                            qntd++;
                            x = 0;
                        }

                        else if (texto[n].ToUpper()[0] == 'D')
                        {
                            palavras[qntd - 1].dicas[x] = texto[n].Remove(0, 2).Trim();
                            x++;
                        }
                    }
                }
            }
            while (encontrado == false);
        }

        //este método cuida do contador de dicas
        static void arrumadicas(StructPalavra[] palavras)
        {
            for (int i = 0; i < palavras.Length; i++)
            {
                try
                {
                    palavras[i].contadorDicas = palavras[i].dicas.Length;
                    palavras[i].blank = false;
                }
                catch
                {
                    palavras[i].blank = true;
                }
            }
        }

        //este método escreve os nomes, RA e tópicos desenvolvidos do jogo
        static void telaInicial()
        {
            Console.WriteLine("Nomes: Filipe Marques de Lima    RA:081170007   EC2\n" +
                              "       David Conde                  081170002      \n\n\n" +
                              "     [X] JOGO  \n     [X] DICAS\n     [X] CONTROLE DE TEMPO ");

            Console.CursorTop = 22;
            Console.CursorLeft = 0;
            escreveBlue("           >>Pressione Enter para começar o jogo.<<");
            Console.ReadLine();
            Console.Clear();
        }

        //este método escreve a abertura do jogo
        static void telaAbreJogo()
        {
            Console.WriteLine("Welcome to THE GAME!" +
                              "\n\n\n\n JOGO DA FORCA  \n" +
                              "\n   REGRAS" +
                              "\n   -Você começa com 10 vidas;" +
                              "\n   -A cada letra errada você perde uma vida;" +
                              "\n   -Você pode pedir dicas a qualquer momento;" +
                              "\n   -Pode ter palavras com menos dicas que outras;" +
                              "\n   -A cada dica solicitada você perde uma vida;" +
                              "\n   -Ao zerar suas vidas você perde o jogo." +
                              "\n   OBS:" +
                              "\n   -Se tiver apenas uma vida e pedir uma dica você perde o jogo.");

            Console.CursorTop = 22;
            Console.CursorLeft = 0;
            escreveBlue("   >>Pressione Enter novamente... mas só se estiver preparado para jogar<<");
            Console.ReadLine();
            Console.Clear();
        }

        //este método serve para controlar o tempo
        static int controledotempo(DateTime inicio)
        {
            double tempoemSegundos;

            Console.CursorLeft = 40;
            Console.CursorTop = 0;
            tempoemSegundos = DateTime.Now.Subtract(inicio).TotalSeconds;

            Console.WriteLine("Ainda restam " + (60 - Math.Truncate(tempoemSegundos)) + "seg.");

            return Convert.ToInt32((60 - Math.Truncate(tempoemSegundos)));
        }

        //este método serve para sortear a palavra e não repete a anterior
        static int sorteiapalavra(int[] sorteio, int rodada, int qtd)
        {
            int sorteada;
            Random rnd = new Random();
            do
            {
                sorteada = rnd.Next(0, qtd);
                if (rodada == 0)
                {
                    sorteio[rodada] = sorteada;
                    return sorteada;
                }
                else if (sorteada != sorteio[rodada - 1])
                {
                    sorteio[rodada] = sorteada;
                    return sorteada;
                }
            }
            while (true);
        }

        //este método serve para escrever a palavra em forma de lacunas
        static void escreveLacuna(string palavra)
        {
            int b;
            Console.CursorLeft = 0;
            Console.CursorTop = 20;

            for (int i = 0; i < palavra.Length; i++)
            {
                Console.CursorLeft = 0;
                Console.CursorTop = 20;

                b = i;
                Console.SetCursorPosition(i + b, 20);
                Console.WriteLine("_");
            }
        }

        #region métodos para escrever colorido
        //este método serve para escrever um texto em azul
        static void escreveBlue(string texto)
        {
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine(texto);
            Console.ForegroundColor = ConsoleColor.White;
        }

        //este método serve para escrever um texto em amarelo
        static void escreveYellow(string texto)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine(texto);
            Console.ForegroundColor = ConsoleColor.White;
        }

        //este método serve para escrever um texto em verde
        static void escreveGreen(string texto)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(texto);
            Console.ForegroundColor = ConsoleColor.White;
        }

        //este método serve para escrever um texto em azul claro(ciano)
        static void escreveCyan(string texto)
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(texto);
            Console.ForegroundColor = ConsoleColor.White;
        }

        //este método serve para escrever um texto em vermelho
        static void escreveRed(string texto)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(texto);
            Console.ForegroundColor = ConsoleColor.White;
        }
        #endregion

        //este método serve para escrever a quantidade de chances(vidas) do jogador
        static void escrevevida(int vida)
        {
            if (vida >= 10)
            {
                Console.SetCursorPosition(0, 0);
                escreveBlue("Vidas: " + vida + " ");
            }

            else if (vida > 5 && vida < 10)
            {
                Console.SetCursorPosition(0, 0);
                escreveGreen("Vidas: " + vida + " ");
            }

            else if (vida >= 3 && vida <= 5)
            {
                Console.SetCursorPosition(0, 0);
                escreveYellow("Vidas: " + vida + " ");
            }

            else if (vida < 3)
            {
                Console.SetCursorPosition(0, 0);
                escreveRed("Vidas: " + vida + " ");
            }
        }

        //este método é a forca(advinhar letra, pedir dica)
        static void forca(int vida, StructPalavra[] palavras, int i, char[] usada, int erros)
        {

            Console.SetCursorPosition(30, 5);
            Console.WriteLine("Dica : {0}", palavras[i].dicas[0]);
            int dica = 1;
            int contaacertos = 0;
            int tempo = 60;
            DateTime datainicio = DateTime.Now;

            do
            {

                tempo = controledotempo(datainicio);

                if (tempo == 0)
                {
                    perdeu();
                }

                if (dica == 1)
                {
                    Console.SetCursorPosition(0, 0);
                    escrevevida(vida);
                    Console.SetCursorPosition(0, 22);
                    escreveCyan("Letra:       ");
                    escreveCyan("       Aperte F2 para a próxima dica ou a letra para o jogo.");
                }

                Console.SetCursorPosition(7, 22);
                if (Console.KeyAvailable)
                {
                    #region if dicas
                    ConsoleKeyInfo tecla = Console.ReadKey();
                    if (tecla.Key.ToString() == "F2")
                    {
                        if (palavras[i].dicas[dica] == null)
                        {
                            Console.SetCursorPosition(30, 5 + dica + 1);
                            escreveBlue("acabaram as dicas");
                        }

                        else if (palavras[i].dicas[dica + 1] != "")
                        {
                            Console.SetCursorPosition(30, 5 + dica);
                            Console.WriteLine("Dica : {0}", palavras[i].dicas[dica]);
                            dica++;
                            vida--;
                            erros++;
                            animacaoErro(erros);
                            escrevevida(vida);
                        }
                    }
                    #endregion

                    #region if teclas
                    else if (palavras[i].palavra.ToUpper().IndexOf(tecla.Key.ToString().ToUpper()) >= 0)
                    {
                        for (int x = 0; x < palavras[i].palavra.Length; x++)
                        {
                            if (palavras[i].palavra.ToUpper()[x] == tecla.Key.ToString().ToUpper()[0])
                            {
                                Console.CursorTop = 20;
                                Console.CursorLeft = x + x;
                                Console.Write(tecla.Key.ToString().ToUpper());
                                escrevevida(vida);
                                if (usada[x] != tecla.Key.ToString().ToUpper()[0])
                                {
                                    usada[x] = tecla.Key.ToString().ToUpper()[0];
                                    contaacertos++;
                                }
                            }
                        }
                    }

                    else if (palavras[i].palavra.ToUpper().IndexOf(tecla.Key.ToString().ToUpper()) == -1)
                    {
                        vida--;
                        erros++;
                        animacaoErro(erros);
                        escrevevida(vida);
                    }
                    #endregion

                    Thread.Sleep(100);
                }

                if (contaacertos == palavras[i].palavra.Length)
                {
                    ganhou();
                    break;
                }

                if (vida == 0)
                {
                    perdeu();
                    break;
                }
            }
            while (vida >= 0 && tempo >= 0);
        }

        //este método vai desenhando conforme o jogador erra
        static void animacaoErro(int erros)
        {
            if (erros == 1)
            {
                Console.SetCursorPosition(0, 5);

                Console.WriteLine(" 9████▀░░░░░░░░░░░░░░░░░▀████");
            }

            else if (erros == 2)
            {
                Console.SetCursorPosition(0, 6);

                Console.WriteLine(" 8███│░░░░░░░░░░░░░░░░░░░│███");
            }
            else if (erros == 3)
            {
                Console.SetCursorPosition(0, 7);

                Console.WriteLine(" 7██▌│░░░░░░░░░░░░░░░░░░░│▐██");
            }
            else if (erros == 4)
            {
                Console.SetCursorPosition(0, 8);

                Console.WriteLine(" 6██░└┐░░░░░░░░░░░░░░░░░┌┘░██");
            }
            else if (erros == 5)
            {
                Console.SetCursorPosition(0, 9);

                Console.WriteLine(" 5██░░└┐░░░░░░░░░░░░░░░┌┘░░██");
            }
            else if (erros == 6)
            {
                Console.SetCursorPosition(0, 10);

                Console.WriteLine(" 4██░░┌┘▄▄▄▄▄░░░░░▄▄▄▄▄└┐░░██");
            }
            else if (erros == 7)
            {
                Console.SetCursorPosition(0, 11);

                Console.WriteLine(" 3██▌░│██████▌░░░▐██████│░▐██");
            }
            else if (erros == 8)
            {
                Console.SetCursorPosition(0, 12);

                Console.WriteLine(" 2███░│▐███▀▀░░▄░░▀▀███▌│░███");
            }
            else if (erros == 9)
            {
                Console.SetCursorPosition(0, 13);

                Console.WriteLine(" 1███▄░░░░░░░░░░░░░░░░░░░▄███");
            }

            else if (erros == 10)
            {
                Console.SetCursorPosition(0, 14);

                Console.WriteLine(" 0█████▄░░░░░░░░░░░░░░▄██████");

                Thread.Sleep(2000);
            }
        }

        //este método exibe mensagem derrota
        static void perdeu()
        {
            Console.SetCursorPosition(30, 3);
            Console.WriteLine(" Errrrou!");

            Console.SetCursorPosition(30, 4);
            escreveRed(" Você Perdeu ^^ ");

            Thread.Sleep(2000);
            Console.Clear();
            escreveRed("         YOU LOSE!");

            Console.WriteLine("████▀░░░░░░░░░░░░░░░░░▀████\n" +

                              "███│░░░░░░░░░░░░░░░░░░░│███\n" +

                              "██▌│░░░░░░░░░░░░░░░░░░░│▐██\n" +

                              "██░└┐░░░░░░░░░░░░░░░░░┌┘░██\n" +

                              "██░░└┐░░░░░░░░░░░░░░░┌┘░░██\n" +

                              "██░░┌┘▄▄▄▄▄░░░░░▄▄▄▄▄└┐░░██\n" +

                              "██▌░│██████▌░░░▐██████│░▐██\n" +

                              "███░│▐███▀▀░░▄░░▀▀███▌│░███\n" +

                              "██▀─┘░░░░░░░▐█▌░░░░░░░└─▀██ \n" +

                              "██▄░░░▄▄▄▓░░▀█▀░░▓▄▄▄░░░▄██ \n" +

                              "████▄─┘██▌░░░░░░░▐██└─▄████ \n" +

                              "█████░░▐█─┬┬┬┬┬┬┬─█▌░░█████ \n" +

                              "████▌░░░▀┬┼┼┼┼┼┼┼┬▀░░░▐████ \n" +

                              "█████▄░░░└┴┴┴┴┴┴┴┘░░░▄█████ \n" +

                              "███████▄░░░░░░░░░░░▄███████\n");

            Thread.Sleep(3500);
        }

        //este método exibe mensagem de vitória
        static void ganhou()
        {
            Console.SetCursorPosition(20, 3);
            Console.WriteLine(" Boa! Parabéns!");

            Console.SetCursorPosition(20, 4);
            escreveRed(" Você Descobriu a palavra! ^^ ");

            Thread.Sleep(2000);
            Console.Clear();

            escreveCyan("                       YOU ROCK!");
            Console.WriteLine("        ´$$$$`                            ,,, \n" +
                              "       ´$$$$$$$`                         ´$$$`\n" +
                              "        `$$$$$$$`                       ´$$$$´\n" +
                              "         `$$$$$$$`    ´$$`    ´$$`    ´$$$$$$´\n" +
                              "          `$$$$$$$` ´$$$$$` ´$$$$$`  ´$$$$$$$´\n" +
                              "           `$$$$$$$ $$$$$$$ $$$$$$$ ´$$$$$$$´\n" +
                              "            `$$$$$$ $$$$$$$ $$$$$$$`´$$$$$$´\n" +
                              "   ,,,      `$$$$$$ $$$$$$$ $$$$$$$ $$$$$$´\n" +
                              " ´$$$$$`    `$$$$$$ $$$$$$$ $$$$$$$ $$$$$$´\n" +
                              "´$$$$$$$$$`´$$$$$$$ $$$$$$$ $$$$$$$ $$$$$´\n" +
                              "´$$$$$$$$$$$$$$$$$$ $$$$$$$ $$$$$$$ $$$$$´\n" +
                              "   `$$$$$$$$$$$$$$$ $$$$$$$ $$$$$$$ $$$$$´\n" +
                              "      `$$$$$$$$$$$$$ $$$$$  $$$$$$$ $$$$$\n" +
                              "       `$$$$$$$$$$$$,   ,$$$,     ,$$$$$´\n" +
                              "         `$$$$$$$$$$$$$$$$$$$$$$$$$$$$$´\n" +
                              "          `$$$$$$$$$$$$$$$$$$$$$$$$$$$´\n" +
                              "            `$$$$$$$$$$$$$$$$$$$$$$$$´\n" +
                              "               `$$$$$$$$$$$$$$$$$$$$´\n");

            Thread.Sleep(3500);
        }

        //este método recebe um booleano para novo jogo
        static bool newgame()
        {
            string ans = "";
            bool deuCerto = false;
            do
            {
                Console.Clear();
                try
                {
                    Console.WriteLine("Deseja jogar novamente? <S/N>");
                    ans = Console.ReadLine().ToUpper();
                    if (ans[0] == 'S' || ans[0] == 'N')
                        deuCerto = true;
                }
                catch
                {
                    Console.WriteLine("Digite 'S' para continuar ou 'N' para sair do jogo");
                }
            }
            while (!deuCerto);

            if (ans[0] == 'S')
                return true;
            else
                return false;
        }
    }
}
