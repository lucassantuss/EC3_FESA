﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Media;
using System.Threading;

namespace Forca
{
    class Program
    {
        struct Agrupar
        {
        public string[] palavras;
        public string[,] dicas;
        }
        //Variaveis referente as Palavras Sorteadas e leitura de letras
        public static ConsoleKeyInfo letra;
        public static string[] palavrassorteadas = new string[100];
        public static string palavrasorteada;
        public static char letraconvert;
        public static char[] letras = new char[25];
        public static int contespaço = 0, indicepalavra, contpalavra = 0;
        //Variaveis referente as Dicas Sorteadas
        public static string[] dicassorteadas = new string[10];
        public static string dicasorteada;
        public static int qtdicaspedidas = 0, contdica = 0, indicedicas, contdicafinal;
        public static int[] contdicas = new int[100];
        public static bool Tudojasorteado = false;
        //Variaveis do Controle de tempo
        public static DateTime inicio;
        public static double tempoemSegundos;
        //Variaveis de Validaçao do jogo
        public static ConsoleKeyInfo saida;
        public static string saidaconvert = "S";
        public static int vidac = 15, acertos, tentativas = 0, vezesjogadas = 0;

        static void Main(string[] args)
        {
            Inicio();
            Agrupar resultado = AgrupandoPalavras();
            ReiniciandoJogo(resultado);
        }
        //Tela inicial
        static void Inicio()
        {
            Console.SetWindowSize(100, 44);
            Console.Title = "Jogo da Forca do Teixeira **F2-Dicas**";
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.WriteLine("Nome: Gabriel Teixeira     RA:081170023" +
                "\nJOGO [X]" +
                "\nDICAS[X]" +
                "\nCONTROLE DE TEMPO[X]" +
                "\nPressione qualquer tecla para continuar....");
            Console.CursorLeft = 0;
            Console.CursorTop = 40;
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Este código é protegido por leis internacionais de software, e pela lei de Deus"
                +"\n\nAfinal de contas só Deus sabe como esse programa funciona, NÃO ALTERAR DESSA LINHA PARA BAIXO");
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.ReadKey();
            Console.Clear();
        }
        //Agrupando palavras e dicas nas variaveis
        static Agrupar AgrupandoPalavras()
        {
            Agrupar Agrupador = new Agrupar();
            Agrupador.palavras = new string[100];
            Agrupador.dicas = new string[100,10];
            string line;
            contpalavra = 0;
            try
            {
                StreamReader sr = new StreamReader("jogo.txt");
                while (!sr.EndOfStream)
                {
                    line = sr.ReadLine();
                    if (line[0] == 'P')
                    {
                        contdica = 0;
                        Agrupador.palavras[contpalavra] = line.Substring(2).ToUpper();
                        contpalavra = contpalavra + 1;
                    }
                    if (line[0] == 'D')
                    {
                        Agrupador.dicas[contpalavra, contdica] = line.Substring(2);
                        contdicas[contpalavra] = contdicafinal + 1;
                        contdica++;
                    }
                    contdicafinal = contdica;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("O Arquivo não foi carregado: ");
                Console.WriteLine(e.Message);
            }
            return Agrupador;
        }
        //Metodo para começar e recomeçar o jogo
        static void ReiniciandoJogo(Agrupar resultado)
        {
            while (saidaconvert == "S")
            {
                IniciandoJogada();
                Vidas();
                palavrasorteada = SortearPalavras(resultado);
                ColocarPalavranaTela(resultado);
                inicio = DateTime.Now;
                TempoETudo(resultado);
            }
        }
        //Sortear a palavra
        static string SortearPalavras(Agrupar resultado)
        {
            Random gerador = new Random();
            indicepalavra = gerador.Next(0, 100);
            for (int i= 0; i< resultado.palavras.Length; i++)
            {
                if (resultado.palavras[indicepalavra] == null)
                {
                    indicepalavra = gerador.Next(0, 100);
                }
                else
                {
                    break;
                }
            }
            palavrasorteada = resultado.palavras[indicepalavra];
            palavrassorteadas[vezesjogadas] = palavrasorteada;
            for (int i = 0; i < palavrassorteadas.Length; i++)
            {
                //if (i == vezesjogadas)
                //    i++;
                if (palavrasorteada == palavrassorteadas[i])
                {
                    indicepalavra = gerador.Next(0, 3);
                    palavrasorteada = resultado.palavras[indicepalavra];
                }
            }
            return palavrasorteada;
        }
        //Colocando os espaços da palavra
        static void ColocarPalavranaTela(Agrupar resultado)
        {
            try
            {
                Console.CursorLeft = 10;
                Console.CursorTop = 16;
                Console.Write("                                           ");
                Console.CursorLeft = 10;
                for (int i = 1; i <= palavrasorteada.Length; i++)
                {
                    if (palavrasorteada[i - 1] == ' ')
                    {
                        Console.Write("  ");
                        contespaço++;
                    }
                    else
                        Console.Write("_ ");
                }
                MostrandoDicas(resultado);
                Console.CursorLeft = 0;
                Console.CursorTop = 19;
                Console.WriteLine("Digite uma letra:                                                             " +
                    "\n                                                                                          " +
                    "\n                                                                                          ");

            }
            catch
            {
                Console.CursorTop = 4;
                Console.CursorLeft = 50;
                Console.Write("ERRO: Ao colocar as palavras na tela");
            }

        }
        //Verificando a letra digitada 
        static char VerificandoErros(Agrupar resultado)
        {
            Console.CursorLeft = 0;
            Console.CursorTop = 19;
            Console.WriteLine("Digite uma letra:                                                             " +
                "\n                                                                                          " +
                "\n                                                                                          ");
            Console.CursorTop = 20;
            letra = Console.ReadKey();
            letraconvert = letra.KeyChar;
            //dicas
            if (letra.Key.ToString() == "F2")
            {
                if (vidac !=0)
                {
                    MostrandoDicas(resultado);
                    if (Tudojasorteado == false)
                    {
                        vidac--;
                        Vidas();
                    }
                    VerificandoErros(resultado);
                }                
            }
            //vendo numeros
            else if (letraconvert == '1' || letraconvert == '2' || letraconvert == '3' || letraconvert == '4' || letraconvert == '5' || letraconvert == '6' || letraconvert == '7' || letraconvert == '8' || letraconvert == '9' || letraconvert == '0')
            {
                Console.CursorTop = 4;
                Console.CursorLeft = 50;
                Console.Write("ERRO: Digite apenas letras                        ");
                TempoETudo(resultado);
                return ' ';
            }
            //vendo Enter
            else if (letra.Key == ConsoleKey.Enter || letra.Key == ConsoleKey.Spacebar)
            {
                Console.CursorTop = 4;
                Console.CursorLeft = 50;
                Console.Write("ERRO: Não digite espaços vazios");
                TempoETudo(resultado);
                return ' ';
            }
            else
            {
                //vendo letras repetidas
                for (int i = 0; i < letras.Length; i++)
                {
                    if (letraconvert == letras[i])
                    {
                        Console.CursorTop = 4;
                        Console.CursorLeft = 50;
                        Console.Write("ERRO: Letra ja digitada                           ");
                        VerificandoErros(resultado);
                    }
                }
                Console.CursorTop = 4;
                Console.CursorLeft = 50;
                Console.Write("                                                 ");
                tentativas++;
            }
            return letraconvert;
        }
        //Escrever a letra ma tela e validar acertos
        static void EscrevendoLetras()
        {
            Console.CursorLeft = 34;
            Console.CursorTop = 16;
            Console.Write("Letras utilizadas: ");
            string letramaiuscula = letraconvert.ToString().ToUpper();
            bool verificador = false;
            Console.CursorLeft = 10;
            Console.CursorTop = 16;
            for (int i = 0; i < palavrasorteada.Length; i++)
            {
                if (letramaiuscula[0] == palavrasorteada[i])
                {
                    Console.CursorLeft = 10 + (i + i);
                    Console.Write(letramaiuscula);
                    acertos++;
                    verificador = true;
                }
            }
            if (verificador == false)
            {
                vidac--;
                Vidas();
            }
            Console.CursorLeft = 54;
            Console.CursorTop = 16;
            for (int i = 0; i < 25; i++)
            {
                Console.Write(letras[i].ToString().ToUpper() + " ");
                if (letras[i] == ' ')
                    break;
            }
            if (acertos == (palavrasorteada.Length - contespaço))
            {
                Console.CursorTop = 18;
                Console.Write("\nVocê venceu o jogo, demonstrando quem é o melhor time do Brasil ;)" +
                                      "\nDeseja tentar novamente?(S-Sim, N-Não)" +
                                      "\n                                                                                                         " +
                                      "\n                                                                                                         " +
                                      "\n                                                                                                         ");
                saida = Console.ReadKey();
                saidaconvert = saida.Key.ToString().ToUpper();
                vidac = 0;
                tentativas = 0;
            }

        }
        //Contador de Vidas
        static void Vidas()
        {
            switch (vidac)
            {
                #region 15-11
                case 15:
                    Console.Clear();
                    Console.CursorTop = 0;
                    Console.CursorLeft = 0;
                    Console.WriteLine("###### Brasileirão 2017 ######                                            ");
                    Console.WriteLine("Objetivo do jogo: Não deixar o corinthians cair." +
                                      "\n00-----------------------------------" +
                                      "\n||                                  |" +
                                      "\n||                                  |" +
                                      "\n||                                  |" +
                                      "\n||                       ---> 05-Corinthians      " +
                                      "\n||                            06-Ceara            " +
                                      "\n||                            07-Paysandu         " +
                                      "\n||                            08-Ribeirão Pires FC" +
                                      "\n||                            09-São Caetano      " +
                                      "\n||                            10-Tabajara FC      " +
                                      "\n||                            11-Santos           " +
                                      "\n||                                                                        " +
                                      "\n||                                                                        " +
                                      "\n||                                                                              " +
                                      "\n||                                                                                              " +
                                      "\n||" +
                                      "\n--------------------------------------------------------------------------");
                    Console.WriteLine("Pressione qualquer tecla para começar a jogar...                               " +
                        "\n                                                                                           " +
                        "\n                                                                                           " +
                                      "\n                                                                                                         " +
                                      "\n                                                                                                         " +
                                      "\n                                                                                                         ");
                    Console.CursorTop = 20;
                    Console.ReadKey();
                    break;

                case 14:
                    Console.CursorTop = 0;
                    Console.CursorLeft = 0;
                    Console.WriteLine("###### Brasileirão 2017 ######");
                    Console.WriteLine("Objetivo do jogo: Não deixar o corinthians cair." +
                                      "\n00-----------------------------------" +
                                      "\n||                                  |" +
                                      "\n||                                  |" +
                                      "\n||                                  |" +
                                      "\n||                       ---> 06-Corinthians         " +
                                      "\n||                            07-Paysandu            " +
                                      "\n||                            08-Ribeirão Pires FC   " +
                                      "\n||                            09-São Caetano         " +
                                      "\n||                            10-Tabajara FC         " +
                                      "\n||                            11-Santos              " +
                                      "\n||                            12-Jarinu FC           " +
                                      "\n||                                                                        " +
                                      "\n||                                                                        " +
                                      "\n||                                                                        " +
                                      "\n||" +
                                      "\n||" +
                                      "\n--------------------------------------------------------------------------");
                    break;
                case 13:
                    Console.CursorTop = 0;
                    Console.CursorLeft = 0;
                    Console.WriteLine("###### Brasileirão 2017 ######");
                    Console.WriteLine("Objetivo do jogo: Não deixar o corinthians cair." +
                                      "\n00-----------------------------------" +
                                      "\n||                                  |" +
                                      "\n||                                  |" +
                                      "\n||                                  |" +
                                      "\n||                       ---> 07-Corinthians         " +
                                      "\n||                            08-Ribeirão Pires FC   " +
                                      "\n||                            09-São Caetano         " +
                                      "\n||                            10-Tabajara FC         " +
                                      "\n||                            11-Santos              " +
                                      "\n||                            12-Jarinu FC           " +
                                      "\n||                            13-Atletico-GO         " +
                                      "\n||                                                                        " +
                                      "\n||                                                                        " +
                                      "\n||                                                                        " +
                                      "\n||" +
                                      "\n||" +
                                      "\n--------------------------------------------------------------------------");
                    break;
                case 12:
                    Console.CursorTop = 0;
                    Console.CursorLeft = 0;
                    Console.WriteLine("###### Brasileirão 2017 ######");
                    Console.WriteLine("Objetivo do jogo: Não deixar o corinthians cair." +
                                      "\n00-----------------------------------" +
                                      "\n||                                  |" +
                                      "\n||                                  |" +
                                      "\n||                                  |" +
                                      "\n||                       ---> 08-Corinthians         " +
                                      "\n||                            09-São Caetano         " +
                                      "\n||                            10-Tabajara FC         " +
                                      "\n||                            11-Santos              " +
                                      "\n||                            12-Jarinu FC           " +
                                      "\n||                            13-Atletico-GO         " +
                                      "\n||                            14-Vitoria             " +
                                      "\n||                                                                        " +
                                      "\n||                                                                        " +
                                      "\n||                                                                        " +
                                      "\n||" +
                                      "\n||" +
                                      "\n--------------------------------------------------------------------------");
                    break;
                case 11:
                    Console.CursorTop = 0;
                    Console.CursorLeft = 0;
                    Console.WriteLine("###### Brasileirão 2017 ######");
                    Console.WriteLine("Objetivo do jogo: Não deixar o corinthians cair." +
                                      "\n00-----------------------------------" +
                                      "\n||                                  |" +
                                      "\n||                                  |" +
                                      "\n||                                  |" +
                                      "\n||                       ---> 09-Corinthians         " +
                                      "\n||                            10-Tabajara FC         " +
                                      "\n||                            11-Santos              " +
                                      "\n||                            12-Jarinu FC           " +
                                      "\n||                            13-Atletico-GO         " +
                                      "\n||                            14-Vitoria             " +
                                      "\n||                            15-Chapecoense         " +
                                      "\n||                                                                        " +
                                      "\n||                                                                        " +
                                      "\n||                                                                        " +
                                      "\n||" +
                                      "\n||" +
                                      "\n--------------------------------------------------------------------------");
                    break;
                #endregion
                #region 10-6
                case 10:
                    Console.CursorTop = 0;
                    Console.CursorLeft = 0;
                    Console.WriteLine("###### Brasileirão 2017 ######");
                    Console.WriteLine("Objetivo do jogo: Não deixar o corinthians cair." +
                                      "\n00-----------------------------------" +
                                      "\n||                                  |" +
                                      "\n||                                  |" +
                                      "\n||                                  |" +
                                      "\n||                       ---> 10-Corinthians         " +
                                      "\n||                            11-Santos              " +
                                      "\n||                            12-Jarinu FC           " +
                                      "\n||                            13-Atletico-GO         " +
                                      "\n||                            14-Vitoria             " +
                                      "\n||                            15-Chapecoense         " +
                                      "\n||                            16-XV de piracicaba    " +
                                      "\n||                                                                        " +
                                      "\n||                                                                        " +
                                      "\n||                                                                        " +
                                      "\n||" +
                                      "\n||" +
                                      "\n--------------------------------------------------------------------------");
                    break;
                case 9:
                    Console.CursorTop = 0;
                    Console.CursorLeft = 0;
                    Console.WriteLine("###### Brasileirão 2017 ######");
                    Console.WriteLine("Objetivo do jogo: Não deixar o corinthians cair." +
                                      "\n00-----------------------------------" +
                                      "\n||                                  |" +
                                      "\n||                                  |" +
                                      "\n||                                  |" +
                                      "\n||                       ---> 11-Corinthians         " +
                                      "\n||                            12-Jarinu FC           " +
                                      "\n||                            13-Atletico-GO         " +
                                      "\n||                            14-Vitoria             " +
                                      "\n||                            15-Chapecoense         " +
                                      "\n||                            16-XV de piracicaba    " +
                                      "\n||                            17-São Paulo           " +
                                      "\n||                                                                        " +
                                      "\n||                                                                        " +
                                      "\n||                                                                        " +
                                      "\n||" +
                                      "\n||" +
                                      "\n--------------------------------------------------------------------------");
                    break;
                case 8:
                    Console.CursorTop = 0;
                    Console.CursorLeft = 0;
                    Console.WriteLine("###### Brasileirão 2017 ######");
                    Console.WriteLine("Objetivo do jogo: Não deixar o corinthians cair." +
                                      "\n00-----------------------------------" +
                                      "\n||                                  |" +
                                      "\n||                                  |" +
                                      "\n||                                  |" +
                                      "\n||                       ---> 12-Corinthians         " +
                                      "\n||                            13-Atletico-GO         " +
                                      "\n||                            14-Vitoria             " +
                                      "\n||                            15-Chapecoense         " +
                                      "\n||                            16-XV de piracicaba    " +
                                      "\n||                            17-São Paulo           " +
                                      "\n||                            18-Ibis                " +
                                      "\n||                                                                        " +
                                      "\n||                                                                        " +
                                      "\n||                                                                        " +
                                      "\n||" +
                                      "\n||" +
                                      "\n--------------------------------------------------------------------------");
                    break;
                case 7:
                    Console.CursorTop = 0;
                    Console.CursorLeft = 0;
                    Console.WriteLine("###### Brasileirão 2017 ######");
                    Console.WriteLine("Objetivo do jogo: Não deixar o corinthians cair." +
                                      "\n00-----------------------------------" +
                                      "\n||                                  |" +
                                      "\n||                                  |" +
                                      "\n||                                  |" +
                                      "\n||                       ---> 13-Corinthians         " +
                                      "\n||                            14-Vitoria             " +
                                      "\n||                            15-Chapecoense         " +
                                      "\n||                            16-XV de piracicaba    " +
                                      "\n||                            17-São Paulo           " +
                                      "\n||                            18-Ibis                " +
                                      "\n||                            19-Palmeiras           " +
                                      "\n||                                                                        " +
                                      "\n||                                                                        " +
                                      "\n||                                                                        " +
                                      "\n||" +
                                      "\n||" +
                                      "\n--------------------------------------------------------------------------");
                    break;
                case 6:
                    Console.CursorTop = 0;
                    Console.CursorLeft = 0;
                    Console.WriteLine("###### Brasileirão 2017 ######");
                    Console.WriteLine("Objetivo do jogo: Não deixar o corinthians cair." +
                                      "\n00-----------------------------------" +
                                      "\n||                                  |" +
                                      "\n||                                  |" +
                                      "\n||                                  |" +
                                      "\n||                       ---> 14-Corinthians         " +
                                      "\n||                            15-Chapecoense         " +
                                      "\n||                            16-XV de piracicaba    " +
                                      "\n||                            17-São Paulo           " +
                                      "\n||                            18-Ibis                " +
                                      "\n||                            19-Palmeiras           " +
                                      "\n||                            20-EC2/ADM4            " +
                                      "\n||                                                                        " +
                                      "\n||                                                                        " +
                                      "\n||                                                                        " +
                                      "\n||" +
                                      "\n||" +
                                      "\n--------------------------------------------------------------------------");
                    break;
                #endregion
                #region 5-1
                case 5:
                    Console.CursorTop = 0;
                    Console.CursorLeft = 0;
                    Console.WriteLine("###### Brasileirão 2017 ######");
                    Console.WriteLine("Objetivo do jogo: Não deixar o corinthians cair." +
                                      "\n00-----------------------------------" +
                                      "\n||                                  |" +
                                      "\n||                                  |" +
                                      "\n||                                  |" +
                                      "\n||                            14-Chapecoense         " +
                                      "\n||                       ---> 15-Corinthians         " +
                                      "\n||                            16-XV de piracicaba    " +
                                      "\n||                            17-São Paulo           " +
                                      "\n||                            18-Ibis                " +
                                      "\n||                            19-Palmeiras           " +
                                      "\n||                            20-EC2/ADM4            " +
                                      "\n||                                  " +
                                      "\n||                                  " +
                                      "\n||                                  " +
                                      "\n||" +
                                      "\n||" +
                                      "\n--------------------------------------------------------------------------");
                    break;
                case 4:
                    Console.CursorTop = 0;
                    Console.CursorLeft = 0;
                    Console.WriteLine("###### Brasileirão 2017 ######");
                    Console.WriteLine("Objetivo do jogo: Não deixar o corinthians cair." +
                                      "\n00-----------------------------------" +
                                      "\n||                                  |" +
                                      "\n||                                  |" +
                                      "\n||                                  |" +
                                      "\n||                            14-Chapecoense       " +
                                      "\n||                            15-XV de piracicaba  " +
                                      "\n||                       ---> 16-Corinthians       " +
                                      "\n||                            17-São Paulo         " +
                                      "\n||                            18-Ibis              " +
                                      "\n||                            19-Palmeiras         " +
                                      "\n||                            20-EC2/ADM4          " +
                                      "\n||                                  " +
                                      "\n||                                  " +
                                      "\n||                                  " +
                                      "\n||" +
                                      "\n||" +
                                      "\n--------------------------------------------------------------------------");
                    break;
                case 3:
                    Console.CursorTop = 0;
                    Console.CursorLeft = 0;
                    Console.WriteLine("###### Brasileirão 2017 ######");
                    Console.WriteLine("Objetivo do jogo: Não deixar o corinthians cair." +
                                      "\n00-----------------------------------" +
                                      "\n||                                  |" +
                                      "\n||                                  |" +
                                      "\n||                                  |" +
                                      "\n||                            14-Chapecoense       " +
                                      "\n||                            15-XV de piracicaba  " +
                                      "\n||                            16-São Paulo         " +
                                      "\n||                       ---> 17-Corinthians       " +
                                      "\n||                            18-Ibis              " +
                                      "\n||                            19-Palmeiras         " +
                                      "\n||                            20-EC2/ADM4          " +
                                      "\n||                                  " +
                                      "\n||                                  " +
                                      "\n||                                  " +
                                      "\n||" +
                                      "\n||" +
                                      "\n--------------------------------------------------------------------------");
                    break;
                case 2:
                    Console.CursorTop = 0;
                    Console.CursorLeft = 0;
                    Console.WriteLine("###### Brasileirão 2017 ######");
                    Console.WriteLine("Objetivo do jogo: Não deixar o corinthians cair." +
                                      "\n00-----------------------------------" +
                                      "\n||                                  |" +
                                      "\n||                                  |" +
                                      "\n||                                  |" +
                                      "\n||                            14-Chapecoense      " +
                                      "\n||                            15-XV de piracicaba " +
                                      "\n||                            16-São Paulo        " +
                                      "\n||                            17-Ibis             " +
                                      "\n||                       ---> 18-Corinthians <--- " +
                                      "\n||                            19-Palmeiras        " +
                                      "\n||                            20-EC2/ADM4         " +
                                      "\n||                                  " +
                                      "\n||                                  " +
                                      "\n||                                  " +
                                      "\n||" +
                                      "\n||" +
                                      "\n--------------------------------------------------------------------------");
                    break;
                case 1:
                    Console.CursorTop = 0;
                    Console.CursorLeft = 0;
                    Console.WriteLine("###### Brasileirão 2017 ######");
                    Console.WriteLine("Objetivo do jogo: Não deixar o corinthians cair." +
                                      "\n00-----------------------------------" +
                                      "\n||                                  |" +
                                      "\n||                                  |" +
                                      "\n||                                  |" +
                                      "\n||                            14-Chapecoense         " +
                                      "\n||                            15-XV de piracicaba    " +
                                      "\n||                            16-São Paulo           " +
                                      "\n||                            17-Ibis                " +
                                      "\n||                            18-Palmeiras           " +
                                      "\n||                       ---> 19-Corinthians <---    " +
                                      "\n||                            20-EC2/ADM4            " +
                                      "\n||                                  " +
                                      "\n||                                  " +
                                      "\n||                                  " +
                                      "\n||" +
                                      "\n||" +
                                      "\n--------------------------------------------------------------------------");
                    break;
                case 0:
                    Console.CursorTop = 0;
                    Console.CursorLeft = 0;
                    Console.WriteLine("###### Brasileirão 2017 ######");
                    Console.WriteLine("Objetivo do jogo: Não deixar o corinthians cair." +
                                      "\n00-----------------------------------" +
                                      "\n||                                  |" +
                                      "\n||                                  |" +
                                      "\n||                                  |" +
                                      "\n||                            14-Chapecoense           " +
                                      "\n||                            15-XV de piracicaba      " +
                                      "\n||                            16-São Paulo             " +
                                      "\n||                            17-Ibis                  " +
                                      "\n||                            18-Palmeiras             " +
                                      "\n||                            19-EC2/ADM4              " +
                                      "\n||                       ---> 20-Corinthians <---" +
                                      "\n||                                  " +
                                      "\n||                           CAIUUUUUUUUU!!!!!!" +
                                      "\n||                                  " +
                                      "\n||" +
                                      "\n||" +
                                      "\n--------------------------------------------------------------------------" +
                                      "\nVocê fez o Corinthians cair infelizmente :(" +
                                      "\nDeseja tentar novamente?(S-Sim, N-Não)" +
                                      "\n                                                                                           " +
                                      "\n                                                                                           " +
                                      "\n                                                                                           ");
                    #endregion
                    saida = Console.ReadKey();
                    saidaconvert = saida.Key.ToString().ToUpper();
                    vidac = 0;
                    tentativas = 0;
                    break;
            }
        }
        //Metodo de inicio de jogadas
        static void IniciandoJogada()
        {
            for (int i = 0; i < letras.Length; i++)
                letras[i] = ' ';
            vidac = 15;
            acertos = 0;
            contespaço = 0;
            tentativas = 0;
            vezesjogadas++;
            qtdicaspedidas = 0;
            Tudojasorteado = false;
        }
        //Metodo para validaçao de tempo e teclas apertadas
        static void TempoETudo(Agrupar resultado)
        {
            while (vidac != 0)
            {
                if (Console.KeyAvailable)
                {
                    letras[tentativas] = VerificandoErros(resultado);
                    EscrevendoLetras();
                }
                Console.CursorLeft = 50;
                Console.CursorTop = 0;
                tempoemSegundos = DateTime.Now.Subtract(inicio).TotalSeconds;
                double Tempocorrido = (180 - Math.Truncate(tempoemSegundos));
                Console.WriteLine("Tempo restante: " + Tempocorrido + " seg.");
                Thread.Sleep(25);
                if (Tempocorrido <= 0)
                {
                    Console.CursorTop = 18;
                    Console.Write("\nVocê fez o Corinthians cair infelizmente :(" +
                                          "\nDeseja tentar novamente?(S-Sim, N-Não)");
                    saida = Console.ReadKey();
                    saidaconvert = saida.Key.ToString().ToUpper();
                    vidac = 0;
                    tentativas = 0;
                }
            }
        }
        //Metodo que mostra as dicas
        static void MostrandoDicas(Agrupar resultado)
        {
            if (qtdicaspedidas < contdicas[indicepalavra+1])
            {
                dicasorteada = resultado.dicas[indicepalavra + 1, qtdicaspedidas];
                dicassorteadas[qtdicaspedidas] = dicasorteada;
                Console.CursorTop = 23;
                Console.CursorLeft = 0;
                Console.Write("Dica: " + dicasorteada + "                                       ");
                qtdicaspedidas++;
            }
            else
            {
                Tudojasorteado = true;
                Console.CursorTop = 23;
                Console.CursorLeft = 0;
                Console.Write("Todas as dicas já sorteadas                                       ");
            }
        }        
    }
}