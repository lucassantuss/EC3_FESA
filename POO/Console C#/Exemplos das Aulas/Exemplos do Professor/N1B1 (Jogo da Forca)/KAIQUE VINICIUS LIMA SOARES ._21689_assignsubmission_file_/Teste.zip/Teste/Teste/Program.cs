﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.IO;


namespace ConsoleApplication46
{
    class Program
    {

        static void Introducao()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Green;
            Console.CursorLeft = 0;
            Console.CursorTop = 10;
            Console.Write("Jogo criado por: Kaique Vinicius Lima Soares  RA: 081170027");
            Console.CursorLeft = 0;
            Console.CursorTop = 13;
            Console.Write("JOGO [X] >>>>> 6 pontos.");
            Console.CursorLeft = 0;
            Console.CursorTop = 14;
            Console.Write("DICAS[X] >>>>> 2 pontos.");
            Console.CursorLeft = 0;
            Console.CursorTop = 15;
            Console.Write("CONTROLE DE TEMPO[] >>>>> 2 pontos.");
            Console.ForegroundColor = ConsoleColor.White;
            Thread.Sleep(5000);
            Console.Clear();
        }
        static void PrintarVitoria()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Green;
            Console.CursorLeft = 15;
            Console.CursorTop = 5;
            Console.WriteLine("¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦");
            Console.CursorLeft = 15;
            Console.WriteLine("¦                                                                                           ¦");
            Console.CursorLeft = 15;
            Console.WriteLine("¦                                              ¦                                            ¦");
            Console.CursorLeft = 15;
            Console.WriteLine("¦                                             ¦                                             ¦");
            Console.CursorLeft = 15;
            Console.WriteLine("¦   ¦             ¦                          ¦                                              ¦");
            Console.CursorLeft = 15;
            Console.WriteLine("¦   ¦             ¦                                                                         ¦");
            Console.CursorLeft = 15;
            Console.WriteLine("¦    ¦           ¦      ¦    ¦ ¦ ¦ ¦ ¦     ¦ ¦ ¦      ¦ ¦ ¦ ¦     ¦      ¦ ¦ ¦ ¦            ¦");
            Console.CursorLeft = 15;
            Console.WriteLine("¦     ¦         ¦                ¦       ¦       ¦    ¦      ¦          ¦       ¦           ¦");
            Console.CursorLeft = 15;
            Console.WriteLine("¦      ¦       ¦        ¦        ¦       ¦       ¦    ¦      ¦    ¦     ¦       ¦           ¦");
            Console.CursorLeft = 15;
            Console.CursorLeft = 15;
            Console.WriteLine("¦      ¦       ¦        ¦        ¦       ¦       ¦    ¦ ¦ ¦ ¦     ¦     ¦ ¦ ¦ ¦ ¦           ¦");
            Console.CursorLeft = 15;
            Console.WriteLine("¦       ¦     ¦         ¦        ¦       ¦       ¦    ¦     ¦     ¦     ¦       ¦           ¦");
            Console.CursorLeft = 15;
            Console.WriteLine("¦       ¦     ¦         ¦        ¦       ¦       ¦    ¦      ¦    ¦     ¦       ¦           ¦");
            Console.CursorLeft = 15;
            Console.WriteLine("¦        ¦   ¦          ¦        ¦       ¦       ¦    ¦      ¦    ¦    ¦         ¦          ¦");
            Console.CursorLeft = 15;
            Console.WriteLine("¦          ¦            ¦        ¦         ¦ ¦ ¦      ¦      ¦    ¦    ¦         ¦          ¦");
            Console.CursorLeft = 15;
            Console.WriteLine("¦                                                                                           ¦");
            Console.CursorLeft = 15;
            Console.WriteLine("¦                                                                                           ¦");
            Console.CursorLeft = 15;
            Console.WriteLine("¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦");
            Console.ForegroundColor = ConsoleColor.White;
            Thread.Sleep(3000);
        }

       
        
        static void PrintarDerrota()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Red;
            Console.CursorLeft = 15;
            Console.CursorTop = 5;
            Console.WriteLine("¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦");
            Console.CursorLeft = 15;
            Console.WriteLine("¦                                                                                           ¦");
            Console.CursorLeft = 15;
            Console.WriteLine("¦                                                                                           ¦");
            Console.CursorLeft = 15;
            Console.WriteLine("¦                                                                                           ¦");
            Console.CursorLeft = 15;
            Console.WriteLine("¦     ¦ ¦ ¦ ¦                                                                               ¦");
            Console.CursorLeft = 15;
            Console.WriteLine("¦     ¦       ¦                                                                             ¦");
            Console.CursorLeft = 15;
            Console.WriteLine("¦     ¦         ¦    ¦ ¦ ¦ ¦    ¦ ¦ ¦      ¦ ¦ ¦       ¦ ¦ ¦ ¦    ¦ ¦ ¦ ¦ ¦     ¦ ¦ ¦       ¦");
            Console.CursorLeft = 15;
            Console.WriteLine("¦     ¦         ¦    ¦          ¦     ¦    ¦     ¦    ¦       ¦       ¦        ¦     ¦      ¦");
            Console.CursorLeft = 15;
            Console.WriteLine("¦     ¦         ¦    ¦          ¦     ¦    ¦     ¦    ¦       ¦       ¦        ¦     ¦      ¦");
            Console.CursorLeft = 15;
            Console.WriteLine("¦     ¦         ¦    ¦ ¦ ¦      ¦ ¦ ¦      ¦ ¦ ¦      ¦       ¦       ¦        ¦ ¦ ¦ ¦      ¦");
            Console.CursorLeft = 15;
            Console.WriteLine("¦     ¦         ¦    ¦          ¦    ¦     ¦    ¦     ¦       ¦       ¦       ¦       ¦     ¦");
            Console.CursorLeft = 15;
            Console.WriteLine("¦     ¦       ¦      ¦          ¦     ¦    ¦     ¦    ¦       ¦       ¦       ¦        ¦    ¦");
            Console.CursorLeft = 15;
            Console.WriteLine("¦     ¦ ¦ ¦ ¦        ¦ ¦ ¦ ¦    ¦     ¦    ¦     ¦     ¦ ¦ ¦ ¦        ¦       ¦        ¦    ¦");
            Console.CursorLeft = 15;
            Console.WriteLine("¦                                                                                           ¦");
            Console.CursorLeft = 15;
            Console.WriteLine("¦                                                                                           ¦");
            Console.CursorLeft = 15;
            Console.WriteLine("¦                                                                                           ¦");
            Console.CursorLeft = 15;
            Console.WriteLine("¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦ ¦");
            Thread.Sleep(2000);
            Console.ForegroundColor = ConsoleColor.White;
        }
        static void PrintarVidas(int vida)
        {
            Console.CursorLeft = 4;
            Console.CursorTop = 1;
            Console.Write("                               ");
            Console.CursorLeft = 4;
            Console.CursorTop = 1;
            if (vida > 8)
            {
                Console.ForegroundColor = ConsoleColor.DarkGreen;
                Console.Write("VIDA ");
            }
            else if (vida > 5)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("VIDA ");
            }
            else if (vida > 2)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("VIDA ");
            }
            else if (vida > 0)
            {
                Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.Write("VIDA ");
            }
            else if (vida == 0)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.Write("ULTIMA CHANCE !");
            }
            Console.CursorLeft = 10;
            for (int i = 0; i < vida; i++)
            {
                Console.Write("¦ ");
            }
            Console.ForegroundColor = ConsoleColor.White;
            Thread.Sleep(10);
            Console.CursorLeft = 0;
            Console.CursorTop = 0;
        }
        static void PrintarLinhas()
        {
            int n;
            n = palavrasorteada.Length;
            
            Console.CursorLeft = 20;
            Console.CursorTop = 12;
            for (int i = 0; i <= n; i++)
                Console.Write("_ ");
        }

        static void Animacao(int vidas)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.CursorLeft = 90;
            Console.WriteLine("|");
            Console.CursorLeft = 90;
            Console.WriteLine("|");
            Console.CursorLeft = 90;
            Console.WriteLine("|");
            Console.CursorLeft = 90;
            Console.WriteLine("|");
            Console.CursorLeft = 90;
            Console.WriteLine("|");
            Console.CursorLeft = 90;
            Console.WriteLine("|");

            Console.ForegroundColor = ConsoleColor.White;

            if (vidas == 6)
            {
                Console.CursorLeft = 88;
                Console.WriteLine(" ¦¦¦         ");
                Console.CursorLeft = 88;
                Console.WriteLine("¦   ¦        ");
                Console.CursorLeft = 88;
                Console.WriteLine(" ¦¦¦         ");
            }

            if (vidas == 5)
            {

                Console.CursorTop = 9;
                Console.CursorLeft = 90;
                Console.WriteLine("|");
                Console.CursorLeft = 90;
                Console.WriteLine("|");
                Console.CursorLeft = 90;
                Console.WriteLine("|");
                Console.CursorLeft = 90;
                Console.WriteLine("|");
                Console.CursorLeft = 90;
            }

            if (vidas == 4)
            {

                Console.CursorTop = 9;
                Console.CursorLeft = 91;
                Console.WriteLine(@"\");
                Console.CursorLeft = 92;
                Console.WriteLine(@"\");
                Console.CursorLeft = 93;
                Console.WriteLine(@"\");
            }

            if (vidas == 3)
            {
                if (vidas == 0)
                    Console.ForegroundColor = ConsoleColor.Red;
                Console.CursorTop = 9;
                Console.CursorLeft = 89;
                Console.WriteLine(@"/");
                Console.CursorLeft = 88;
                Console.WriteLine(@"/");
                Console.CursorLeft = 87;
                Console.WriteLine(@"/");
            }

            if (vidas == 2)
            {

                Console.CursorTop = 13;
                Console.CursorLeft = 89;
                Console.WriteLine(@"/");
                Console.CursorLeft = 88;
                Console.WriteLine(@"/");
                Console.CursorLeft = 87;
                Console.WriteLine(@"/");
            }

            if (vidas == 1)
            {

                Console.CursorTop = 13;
                Console.CursorLeft = 91;
                Console.WriteLine(@"\");
                Console.CursorLeft = 92;
                Console.WriteLine(@"\");
                Console.CursorLeft = 93;
                Console.WriteLine(@"\");
            }


            if (vidas == 0)
            {
                Console.WriteLine("Ultima chance");
            }
        }
        static void PrintarLetraCorreta(int i, string tecla)
        {
            Console.CursorLeft = 20 + (i * 2);
            Console.CursorTop = 12;
            Console.Write(tecla);
            
        }  



        static int p;
        static string palavrasorteada;
        static void Palavra()

        {
            for (int l = 0; l <= palavrasorteada.Length; l++) ;
            Console.WriteLine("_");
        }
        static void PrintarLinhas(int n)
        {
            n = palavrasorteada.Length - 3;
           
            Console.CursorLeft = 20;
            Console.CursorTop = 12;
            for (int i = 0; i <= n; i++)
                Console.Write("_ ");
        }
        static string LerTeclado()
        {

            string tecla_letra;
            
            if (Console.KeyAvailable) 
            {
                Console.CursorLeft = 20;
                Console.CursorTop = 25;
                ConsoleKeyInfo tecla = Console.ReadKey();
                if (tecla.Key.ToString() == "F2")
                    return "F2";
                else
                {
                    //Caso não seja F2, ele retornará o que o usuário digitar
                    tecla_letra = tecla.Key.ToString();
                    Console.CursorLeft = 20;
                    Console.WriteLine("    ");

                    return tecla_letra;
                }
            }
            else
                return null;
        }
        static bool ValidarLetraDigitada(string tecla)
        {
            string alfabeto = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";

            if (tecla == "F2")
                return true;
            else
            {

                for (int i = 0; i < alfabeto.Length; i++)
                {
                    try
                    {
                        if (tecla == Convert.ToString(alfabeto[i]))
                            return true;
                    }
                    catch
                    {
                        return false;
                    }
                }
                return false;
            }
        }


        static string[] dicas = new string[5];
        static string[] linhas = new string[100];
        static string[] acertos = new string[20];
        static string[] erros = new string[20];
        static bool fimdojogo = false;
        static void Main(string[] args)
        {
            Introducao();
            DateTime inicio = DateTime.Now;
            int x = 20;
            int vidas = 9;
            
            bool validacao = false;

            do
            {
                try
                {
                    linhas = File.ReadAllLines("jogo.txt", Encoding.UTF8);
                    validacao = true;
                }
                catch
                {
                   
                   
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write("Arquivo não encontrado, verifique e o arquivo jogo.txt está na pasta debug \n feche o progama e tente novamente");
                 
                    
                }
            }
            while (!validacao);
           
            do
            {
                Random gerador = new Random();
                int aleatorio = 121;
                palavrasorteada = null;
                string verificador = null;
                int c = 0;
                validacao = false;
                do
                {
                    try
                    {
                        for (int teste = 0; teste <= 1000; teste++)
                        {
                        c:
                            aleatorio = gerador.Next(0, 100);
                            verificador = linhas[aleatorio];
                            if (aleatorio > linhas.Length)
                                goto c;

                            if (verificador[0] == 'P')
                            {

                                palavrasorteada = verificador;
                                validacao = true;
                                break;
                            }
                        }

                    }
                    catch
                    {

                    }
                } while (!validacao);

                string ver;



                for (int n = 0; n < dicas.Length; n++)
                {
                    try
                    {
                        aleatorio++;
                        dicas[n] = linhas[aleatorio];

                        ver = dicas[n];
                        if (ver[0] == 'P')
                            break;
                    }
                    catch
                    {
                        Console.WriteLine("Erro nas dicas");
                    }
                }


                string tecla;
                string palavrapronta = palavrasorteada.Substring(3);
                int acert = palavrapronta.Length - 2;
                string valida = " ";
                int j = palavrapronta.Length;

                Console.WriteLine("Digite qualquer tecla");
                Console.CursorTop = 0;
                Console.CursorLeft = 0;
                Thread.Sleep(2000);
                Console.Write("                             ");
                Console.CursorTop = 12;
                Console.CursorLeft = 20;
                for (int n = 0; n <= j; n++)
                    Console.Write("_ ");





                    do
                    {

                        do
                        {
                        L:
                            tecla = LerTeclado();
                            if (tecla == null)
                                validacao = true;
                        } while (false);


                        validacao = ValidarLetraDigitada(tecla);
                        validacao = false;
                        bool valid = false;

                        if (tecla != null)
                        {

                            Console.CursorLeft = 80;
                            Console.CursorTop = 20;
                            Console.Write("Digite F2 para receber dicas");

                            Console.CursorTop = 10;
                            Console.CursorLeft = 50;
                            Console.WriteLine("Letra digitada:{0} ", tecla);
                            if (tecla == "F2")
                            {
                                try
                                {
                                    Console.CursorTop = x;
                                    Console.WriteLine(dicas[c].Substring(3));

                                    c++;
                                    x++;
                                    vidas--;
                                    PrintarVidas(vidas);
                                    Animacao(vidas);



                                }
                                catch
                                {
                                    Console.WriteLine("Acabaram as dicas");
                                }
                            }
                            else
                            {

                                bool letracorreta = false;
                                for (int i = 0; i < palavrapronta.Length; i++)
                                {
                                    if (palavrapronta[i].ToString() == tecla)
                                    {
                                        letracorreta = true;
                                        validacao = false;
                                        PrintarLetraCorreta(i, tecla);
                                    }
                                }

                                for (int k = 0; k < valida.Length; k++)
                                {
                                    if (tecla == valida[k].ToString())
                                        valid = true;
                                }
                                valida += tecla;
                                if (valid)
                                    acert++;

                                if (letracorreta == true)
                                {
                                    acert--;
                                }

                                if (!letracorreta)
                                {
                                    vidas--;
                                    Console.CursorTop = 0;
                                    Console.CursorLeft = 0;
                                    PrintarVidas(vidas);
                                    Animacao(vidas);

                                }

                                if (acert == 0)
                                {
                                    PrintarVitoria();
                                    fimdojogo = true;
                                }
                                if (vidas == -1)
                                {

                                    PrintarDerrota();
                                    fimdojogo = false;
                                }









                            }
                        }
                    } while (!fimdojogo);
                
            } while (!fimdojogo);

        }
    }
}
