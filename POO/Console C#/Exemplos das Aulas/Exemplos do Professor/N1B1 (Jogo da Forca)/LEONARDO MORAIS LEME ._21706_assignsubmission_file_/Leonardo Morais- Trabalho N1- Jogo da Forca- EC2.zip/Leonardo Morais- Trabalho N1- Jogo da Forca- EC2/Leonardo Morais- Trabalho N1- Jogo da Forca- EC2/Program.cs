﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Threading;

namespace Core_Project
{
    class Program
    {
        static PalavrasEDicas[] vetor = new PalavrasEDicas[100];

        struct PalavrasEDicas
        {
            public string palavra;
            public string[] dicas;
            public int numerodedicas;
            public bool foijogado;
        }

        /// <summary>
        /// Esse método é utilizado par averificar a existencia do arquivo texto.
        /// </summary>
        static void ValidadorArquivo()
        {
            bool validadorarquivotxt = false; // Variavel utilizada para formar o Loop de verificacao do arquivo texto.
            do
            {
                validadorarquivotxt = false; // Coloca o validador como falso, caso a pessoa esteja verificando pela segunda ou n vez.

                if (File.Exists("jogo.txt")) // se o jogo existir ele muda a variavel para true e sai do Loop.
                    validadorarquivotxt = true;
                else // Caso o arquivo nao exista ele avisa o usuario e espera o enter para verificar novamente.
                {
                    Console.WriteLine("O arquivo texto nao foi encontrado...\n\nPressione enter para continuar");
                    Console.ReadLine();
                }

            }
            while (validadorarquivotxt == false);

            Console.Clear(); // Limpa a tela e escreve que o jogo esta prestes a comecar.
            Console.WriteLine("texto reconhecido com sucesso, aperte enter para começar a jogar!");
            Console.ReadLine();
        }

        /// <summary>
        /// Esse método escreve na tela os dados do aluno e a tela de inicio do jogo da forca.
        /// </summary>
        static void Entrada()
        {
            Console.WriteLine("ALUNO: Leonardo Morais Leme \nRA: 081170010 \nJOGO[X] >>>>>> 6 pontos" +
                "\nDicas[X] >>>>>> 2 pontos \nControle de Tempo[X] >>>>>> 2 pontos \n\n Pressione enter para entrar no jogo!");
            Console.ReadLine();
            Console.Clear();


            bool validadorentrada = false;
            Console.CursorVisible = false;
            bool pisca = false;
            Console.Write(
            @"                                                                     " + "\n" +
            @"       ╔════════════╗╔════════════╗╔════════════╗╔════════════╗      " + "\n" +
            @"       ╚══════╗  ╔══╝║ ╔════════╗ ║║ ╔═══════╗  ║║ ╔════════╗ ║      " + "\n" +
            @"              ║  ║   ║ ║        ║ ║║ ║       ╚══╝║ ║        ║ ║      " + "\n" +
            @"              ║  ║   ║ ║        ║ ║║ ║   ╔══════╗║ ║        ║ ║      " + "\n" +
            @"       ╔══╗   ║  ║   ║ ║        ║ ║║ ║   ╚════╗ ║║ ║        ║ ║      " + "\n" +
            @"       ║  ╚═══╝  ║   ║ ╚════════╝ ║║ ╚════════╝ ║║ ╚════════╝ ║      " + "\n" +
            @"       ╚═════════╝   ╚════════════╝╚════════════╝╚════════════╝      " + "\n" +
            @"                     ╔════════════╗╔════════════╗                    " + "\n" +
            @"                     ╚═╗ ╔═════╗  ║║  ╔══════╗  ║                    " + "\n" +
            @"                       ║ ║     ║  ║║  ║      ║  ║                    " + "\n" +
            @"                       ║ ║     ║  ║║  ╚══════╝  ║                    " + "\n" +
            @"                       ║ ║     ║  ║║  ╔══════╗  ║                    " + "\n" +
            @"                     ╔═╝ ╚═════╝  ║║  ║      ║  ║                    " + "\n" +
            @"                     ╚════════════╝╚══╝      ╚══╝                    " + "\n" +
            @"                                                                     " + "\n" +
            @"╔════════════╗╔════════════╗╔════════════╗╔═══════════╗╔════════════╗" + "\n" +
            @"║  ╔═════════╝║ ╔════════╗ ║║   ╔═════╗  ║║  ╔════════╝║  ╔══════╗  ║" + "\n" +
            @"║  ║          ║ ║        ║ ║║   ╚═════╝  ║║  ║         ║  ║      ║  ║" + "\n" +
            @"║  ╚═════╗    ║ ║        ║ ║║  ╔═╗   ╔═══╝║  ║         ║  ╚══════╝  ║" + "\n" +
            @"║  ╔═════╝    ║ ║        ║ ║║  ║ ╚═╗ ╚═╗  ║  ║         ║  ╔══════╗  ║" + "\n" +
            @"║  ║          ║ ╚════════╝ ║║  ║   ╚═╗ ╚═╗║  ╚════════╗║  ║      ║  ║" + "\n" +
            @"╚══╝          ╚════════════╝╚══╝     ╚═══╝╚═══════════╝╚══╝      ╚══╝" + "\n" +
            @"                       Pressione Enter Para continuar                ");

            do // Loop criado para fazer a tela piscar enquanto o usuario nao aperta enter, nesse caso, so a ultima linha.
            {

                validadorentrada = false;
                if (pisca == true) // Verifica se a ultima linha esta acesa ou apagada. Varia entre as duas. 
                {
                    pisca = false;
                    Console.CursorTop = 23;
                    Console.CursorLeft = 23;
                    Console.Write("Pressione Enter Para continuar");
                    Thread.Sleep(500);
                }
                else
                {
                    pisca = true;
                    Console.CursorTop = 23;
                    Console.CursorLeft = 23;
                    Console.Write("                                ");
                    Thread.Sleep(500);
                }

                if (Console.KeyAvailable) // verifica se a tecla foi apertada e se ela e enter, para quebrar o Loop.
                {
                    ConsoleKeyInfo tecla = Console.ReadKey();
                    string tecla1 = Convert.ToString(tecla.Key);
                    if (tecla.Key.ToString() == "Enter")
                    {
                        validadorentrada = true;
                        Console.Clear();
                    }
                }

            }
            while (validadorentrada == false);
        }

        /// <summary>
        /// Esse método sorteia um inteiro, que vai ser uma posição do vetor de estruturas.
        /// </summary>
        /// <param name="contadorpalavras"></param>
        /// <param name="contadorjogadas"></param>
        /// <returns>Esse método restornará um número positivo, para jogar a palavra OU -1 caso todas as palavras tenham sido jogadas.</returns>
        static int SorteioDePalavra(int contadorpalavras, int contadorjogadas)
        {
            bool palavradisponivel = true; // Variavel utilizada para criar o Loop ate que uma variavel nao jogada seja sorteada.
            int aleatorio = 0;
            Random rnd = new Random(); // variavel randomica para sorteio de palavra do jogo.

            do
            {
                aleatorio = rnd.Next(0, contadorpalavras); // sorteia um numero de 0 ate o numero de palavras no vetor lido anteriormente.
                if (vetor[aleatorio].foijogado == false) // se a a palavra nao foi jogada ele entra no if.
                {
                    vetor[aleatorio].foijogado = true; // coloca que a palavra ja foi jogada na posicao foijogado do vetor.
                    palavradisponivel = false; // quebra o Loop

                }
                else if (contadorjogadas == contadorpalavras) // Verifica se as palavras que ele ja jogou sao igual ao total de palavras.
                {
                    Console.WriteLine("Todas as palavras foram jogadas..."); // se for igual, todas as palavras foram jogadas e retorna -1.
                    return -1;
                }
            }
            while (palavradisponivel == true);
            return aleatorio; // Caso a palavra nao tenha sido jogada ainda ele retorna o numero sorteado. 
        }

        /// <summary>
        /// Metodo utilizado para montar a tela da HoraDeJogar, com as palavras fixas.
        /// </summary>
        /// <param name="palavraescolhida"></param>
        static void ComecoDoJogo(int palavraescolhida)
        {
            Console.Clear();
            Console.CursorVisible = false;
            Console.CursorTop = 14;
            Console.CursorLeft = 0;
            Console.Write("Para dicas, aperte F2");
            Console.CursorTop = 19;
            Console.CursorLeft = 0;
            Console.Write("Letra Digitada: ");
            Console.CursorLeft = 0;
            Console.CursorTop = 20;
            Console.Write("Letras Erradas: ");
            Console.CursorTop = 21;
            Console.CursorLeft = 0;
            Console.Write("Letras Corretas: ");
            Console.CursorTop = 23;
            Console.CursorLeft = 0;
            Console.Write("Palavra:");
        }

        /// <summary>
        ///  Esse método cria o final da tela do jogo, junto com o controle de tempo e a animação.
        /// </summary>
        /// <param name="tempodecorrido"></param>
        /// <param name="animacao"></param>
        static void FinalDoJogo(double tempodecorrido, string[] animacao)
        {
            Console.CursorTop = 0;
            Console.CursorLeft = 0;
            if (tempodecorrido < 60)
                Console.Write(animacao[Convert.ToInt32(tempodecorrido)]);

            Console.CursorLeft = 30;
            Console.CursorTop = 14;
            Console.Write("                            ");
            Console.CursorLeft = 30;
            Console.Write("Tempo Restante = {0}", 60 - tempodecorrido);

            Thread.Sleep(250);
            LimpaMeiaTela();
        }

        /// <summary>
        /// Esse método é utilizado para apagar somente a parte da animação da tela.
        /// </summary>
        static void LimpaMeiaTela()
        {
            // Metodo utilizado para limpar a parte de animacao da HoraDeJogar.
            Console.CursorTop = 0;
            Console.CursorLeft = 0; // Posiciona o Cursor no comeco da tela e "apaga" as primeiras linhas.
            Console.WriteLine(
                @"                                                                        " + "\n" +
                @"                                                                        " + "\n" +
                @"                                                                        " + "\n" +
                @"                                                                        " + "\n" +
                @"                                                                        " + "\n" +
                @"                                                                        " + "\n" +
                @"                                                                        " + "\n" +
                @"                                                                        " + "\n" +
                @"                                                                        " + "\n" +
                @"                                                                        " + "\n" +
                @"                                                                        " + "\n" +
                @"                                                                        " + "\n" +
                @"                                                                        " + "\n" +
                @"                                                                        ");
        }

        /// <summary>
        /// Esse método realiza as modificações na tela conforme o usuário ganha ou perde.
        /// </summary>
        /// <param name="ganhou"></param>
        static void GanhouOuPerdeu(bool ganhou)
        {
            Console.Clear();
            if (ganhou == false)
                Console.Write(
            @"                                                                     " + "\n" +
            @"                                                                     " + "\n" +
            @"                                                                     " + "\n" +
            @"             ╔══╗     ╔══╗ ╔════════════╗╔══╗      ╔══╗              " + "\n" +
            @"              \  \   /  /  ║ ╔════════╗ ║║  ║      ║  ║              " + "\n" +
            @"               \  \ /  /   ║ ║        ║ ║║  ║      ║  ║              " + "\n" +
            @"                \     /    ║ ║        ║ ║║  ║      ║  ║              " + "\n" +
            @"                 ║   ║     ║ ║        ║ ║║  ║      ║  ║              " + "\n" +
            @"                 ║   ║     ║ ╚════════╝ ║║  ╚══════╝  ║              " + "\n" +
            @"                 ╚═══╝     ╚════════════╝╚════════════╝              " + "\n" +
            @"                                                                     " + "\n" +
            @"       ╔══╗         ╔════════════╗╔════════════╗╔════════════╗       " + "\n" +
            @"       ║  ║         ║ ╔════════╗ ║║ ╔══════════╝║ ╔══════════╝       " + "\n" +
            @"       ║  ║         ║ ║        ║ ║║ ║           ║ ║                  " + "\n" +
            @"       ║  ║         ║ ║        ║ ║║ ╚══════════╗║ ╚══════╗           " + "\n" +
            @"       ║  ║         ║ ║        ║ ║╚══════════╗ ║║ ╔══════╝           " + "\n" +
            @"       ║  ╚════════╗║ ╚════════╝ ║╔══════════╝ ║║ ╚══════════╗       " + "\n" +
            @"       ╚═══════════╝╚════════════╝╚════════════╝╚════════════╝       " + "\n" +
            @"                                                                     " + "\n" +
            @"                                                                     " + "\n" +
            @"                                                                     ");
            else
                Console.Write(
            @"                                                                     " + "\n" +
            @"                                                                     " + "\n" +
            @"                                                                     " + "\n" +
            @"             ╔══╗     ╔══╗ ╔════════════╗╔══╗      ╔══╗              " + "\n" +
            @"              \  \   /  /  ║ ╔════════╗ ║║  ║      ║  ║              " + "\n" +
            @"               \  \ /  /   ║ ║        ║ ║║  ║      ║  ║              " + "\n" +
            @"                \     /    ║ ║        ║ ║║  ║      ║  ║              " + "\n" +
            @"                 ║   ║     ║ ║        ║ ║║  ║      ║  ║              " + "\n" +
            @"                 ║   ║     ║ ╚════════╝ ║║  ╚══════╝  ║              " + "\n" +
            @"                 ╚═══╝     ╚════════════╝╚════════════╝              " + "\n" +
            @"                                                                     " + "\n" +
            @"           ╔══╗                 ╔══╗ ╔════╗ ╔═══\    ╔══╗            " + "\n" +
            @"           \  \                /  /  ║    ║ ║    \   ║  ║            " + "\n" +
            @"            \  \      /\      /  /   ║    ║ ║  ║\ \  ║  ║            " + "\n" +
            @"             \  \    //\\    /  /    ║    ║ ║  ║ \ \ ║  ║            " + "\n" +
            @"              \  \  //  \\  /  /     ║    ║ ║  ║  \ \║  ║            " + "\n" +
            @"               \  \//    \\/  /      ║    ║ ║  ║   \ ║  ║            " + "\n" +
            @"                \  /      \  /       ║    ║ ║  ║    \   ║            " + "\n" +
            @"                 \/        \/        ╚════╝ ╚══╝     \══╝            " + "\n" +
            @"                                                                     " + "\n" +
            @"                                                                     ");
        }

        /// <summary>
        /// Esse método é utilizado para verificar se o usuário ganhou ou perdeu e escrever na tela.
        /// </summary>
        /// <param name="tecla1"></param>
        /// <returns></returns>
        static bool ValidadorDaLetra(string tecla1)
        {
            try
            {
                int valorchar = Convert.ToInt32((Convert.ToChar(tecla1.ToUpper())));
                if (valorchar >= 65 && valorchar <= 90)
                {
                    return true;
                }
            }
            catch
            {
                return false;
            }
            return false;
        }
        
        /// <summary>
        /// Método Utilizado para ver se o usuário digitou uma letra valida(de A ate Z) ou F2.
        /// </summary>
        /// <param name="tecla1"></param>
        /// <returns>O método retorna true para letra válida e false para inválida.</returns>
        static bool VerificaLetraValida(string tecla1)
        {
            if (tecla1 == "F2")
                return true;
            try
            {
                int numerodaletra = Convert.ToInt32(Convert.ToChar(tecla1.ToUpper()));
                if (numerodaletra >= 65 && numerodaletra <= 90)
                    return true;
                else
                    return false;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Esse método é utilizado na hora que o programa sorteia uma palavra e inicia o jogo em si.
        /// </summary>
        /// <param name="palavraescolhida"></param>
        static void HoraDeJogar(int palavraescolhida)
        {
            #region Variaveis Inicio e Animacao OK

            DateTime inicio = DateTime.Now; // Variável criada na hora que o jogo inicia, para monitorar o tempo.
            double tempodecorrido = 0; // Variável auxiliar do controle de tempo, apresenta um número double para ser mais facil de trabalhar.
            int erro = 0, letrasacertadas = 0; // erro usado para "acelerar o tempo" caso o usuário erre ou peça uma dica. Letras acertadas é utilizada para monitorar a vitória do usuário.
            string[] animacao = new string[60]; // Vetor de posiçoes string para montar uma animação frame por frame.
            #region Frames da Animacao OK

            animacao[0] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/()                                                     ||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[1] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/=()                                                    ||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[2] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/==()                                                   ||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[3] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/ ==()                                                  ||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[4] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/  ==()                                                 ||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[5] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/   ==()                                                ||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[6] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/    ==()                                               ||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[7] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/     ==()                                              ||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[8] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/      ==()                                             ||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[9] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/       ==()                                            ||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[10] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/        ==()                                           ||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[11] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/         ==()                                          ||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[12] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/          ==()                                         ||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[13] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/           ==()                                        ||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[14] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/            ==()                                       ||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[15] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/             ==()                                      ||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[16] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/              ==()                                     ||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[17] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/               ==()                                    ||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[18] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/                ==()                                   ||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[19] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/                 ==()                                  ||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[20] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/                  ==()                                 ||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[21] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/                   ==()                                ||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[22] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/                    ==()                               ||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[23] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/                     ==()                              ||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[24] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/                      ==()                             ||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[25] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/                       ==()                            ||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[26] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/                        ==()                           ||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[27] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/                         ==()                          ||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[28] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/                          ==()                         ||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[29] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/                           ==()                        ||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[30] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/                            ==()                       ||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[31] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/                             ==()                      ||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[32] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/                              ==()                     ||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[33] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/                               ==()                    ||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[34] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/                                ==()                   ||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[35] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/                                 ==()                  ||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[36] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/                                  ==()                 ||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[37] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/                                   ==()                ||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[38] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/                                    ==()               ||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[39] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/                                     ==()              ||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[40] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/                                      ==()             ||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[41] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/                                       ==()            ||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[42] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/                                        ==()           ||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[43] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/                                         ==()          ||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[44] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/                                          ==()         ||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[45] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/                                           ==()        ||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[46] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/                                            ==()       ||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[47] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/                                             ==()      ||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[48] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/                                              ==()     ||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[49] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/                                               ==()    ||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[50] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/                                                ==()   ||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[51] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/                                                 ==()  ||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[52] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/                                                  ==() ||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[53] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/                                                   ==()||      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[54] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/                                                    ==()|      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[55] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/                                                     ==()      " + "\n" +
                @"    |\                                                       ||      " + "\n" +
                @"    | \                                                    0 /       " + "\n" +
                @"   / \                                                    /|/        " + "\n" +
                @"  /   \                                                  / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[56] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/                                                      ==()     " + "\n" +
                @"    |\                                                               " + "\n" +
                @"    | \                                                      ||      " + "\n" +
                @"   / \                                                     0 /       " + "\n" +
                @"  /   \                                                   /|/        " + "\n" +
                @"                                                         / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[57] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/                                                       ==()    " + "\n" +
                @"    |\                                                               " + "\n" +
                @"    | \                                                              " + "\n" +
                @"   / \                                                       ||      " + "\n" +
                @"  /   \                                                    0 /       " + "\n" +
                @"                                                          /|/        " + "\n" +
                @"                                                         / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[58] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/                                                        ==()   " + "\n" +
                @"    |\                                                               " + "\n" +
                @"    | \                                                              " + "\n" +
                @"   / \                                                               " + "\n" +
                @"  /   \                                                      ||      " + "\n" +
                @"                                                           0 /       " + "\n" +
                @"                                                          /|/        " + "\n" +
                @"                                                         / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                                     " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            animacao[59] =
                @"    0 /                                                      ||      " + "\n" +
                @"    |/                                                         ==()  " + "\n" +
                @"    |\                                                               " + "\n" +
                @"    | \                                                              " + "\n" +
                @"   / \                                                               " + "\n" +
                @"  /   \                                                              " + "\n" +
                @"                                                             ||      " + "\n" +
                @"                                                           0 /       " + "\n" +
                @"                                                          /|/        " + "\n" +
                @"                                                         / |         " + "\n" +
                @"                                                           |         " + "\n" +
                @"                                                          / \        " + "\n" +
                @"                                                         /   \       " + "\n" +
                @"                                                /\/\/\/\/\/\/\/\/\/\/\/";
            #endregion
            string[] LetraPorLetra = new string[vetor[palavraescolhida].palavra.Length]; // Vetor utilizado para trabalhar com cada posiçao da palavra sorteada.
            string[] LetrasTentadas = new string[30]; // Vetor utilizado para monitorar quais letras o usuário já jogou.

            #endregion 

            #region Colocar a Palavra no vetor OK

            for (int n = 0; n < vetor[palavraescolhida].palavra.Length; n++) // Loop para analisar e armazenar as letras da palavra sorteada.
            {
                if (" " != Convert.ToString(vetor[palavraescolhida].palavra[n]))// Se a letra for correta e diferente de espaço.
                {
                    LetraPorLetra[n] = Convert.ToString(vetor[palavraescolhida].palavra[n]);// Armazena no Vetor.
                    LetraPorLetra[n] = LetraPorLetra[n].ToUpper();// para trabalhar somente com letras maiusculas o jogo inteiro.
                    Console.Write("_ ");// para mostrar na tela o número de letras que a palavra sorteada possui.
                }
                else// se a palavra tiver um espaço.
                {
                    Console.Write("  "); // Aparece um espaço na tela 
                    letrasacertadas++;// como o espaço sempre esta certo, a pessoa o acerta utomaticamente.
                }
            }
            #endregion

            #region Variaveis do Jogo OK

            int contadorletracerta = 0, contadorletraerrada = 0, contadorletrastentadas = 0, linhadadica = 0;
            int contadordicaspedidas = 0, auxiliaracertou = 0;
            bool validadorletratentada = false, validadorletra = false, ganhou = false;
            #endregion

            linhadadica = DicaPedida(contadordicaspedidas, linhadadica, palavraescolhida); // Retorna a posição que a dica deve ser escrita. 
            contadordicaspedidas++; // Conta mais uma dica, para nao acontecer de o usuário pedir mais dicas do que tem.

            do // Loop criado para ler a letra que o usuário digitou.
            {
                validadorletratentada = false; // Variavel utilizada para ver se a letra ja foi tentada.
                auxiliaracertou = 0; // Variavel utilizada para ver quantas letras o usuário acertou na rodada.

                Console.CursorLeft = 16; // Posicipna o cursor na posoção de LetraDigitada.
                Console.CursorTop = 19;
                if (Console.KeyAvailable) // Se alguma tecla estiver apertada.
                {
                    ConsoleKeyInfo tecla = Console.ReadKey(); // Le a tecla que o usuário apertou.
                    string tecla1 = (Convert.ToString(tecla.Key)); // Converte a tecla apertada para string.

                    if (VerificaLetraValida(tecla1) == true) // Método utilizado para ver se a letra é válida ou se é F2;
                    {

                        #region Verifica se a letra ja foi jogada OU letra pertence as letras OK

                        for (int n = 0; n < LetrasTentadas.Length; n++) // Repetição criada para verificar letra por letra de palavras ja jogadas.
                        {
                            if (tecla1 == LetrasTentadas[n] && tecla1 != "F2") // Caso a letra tenha sido jogada.
                            {
                                validadorletratentada = true; // o validador muda seu valor para true.
                                break;
                            }
                        }

                        #endregion

                        #region Verificador Letra Certa/Dica/Errada OK

                        validadorletra = ValidadorDaLetra(tecla1);
                        if (validadorletratentada == false && validadorletra == true || tecla1 == "F2")
                        {
                            contadorletrastentadas++; // Muda a posição do vetor de letras tentadas.
                            LetrasTentadas[contadorletrastentadas] = tecla1; // Armazena a nova letra tentada pelo usuário.

                            auxiliaracertou = LetraCorreta(LetraPorLetra, tecla1, contadorletracerta); // Método verifica quantas vezes o usuário acertou nessa rodada.
                            letrasacertadas = letrasacertadas + auxiliaracertou; // O total de letras acertadas, sera oq ja tinha na variavel, mais essa rodada.

                            if (auxiliaracertou != 0)// Se ele acertou a letra nessa rodada, a linha de letra certa escreve a letra e da um espaço para a proxima letra.
                            {
                                contadorletracerta += 2;
                                ganhou = Ganhou(letrasacertadas, palavraescolhida); //Verifica se nessa rodada o usuário ganhou o jogo.
                            }

                            else if (tecla1 == "F2") // Caso o Usuário queira uma dica.
                            {
                                linhadadica = DicaPedida(contadordicaspedidas, linhadadica, palavraescolhida); // O método escreve a dia em sua respectiva linha.
                                if (linhadadica >= 0)// Se retornou um valor positivo, ele conta como erro. Se for Negativo, nao tem dicas disponíveis.
                                {
                                    contadordicaspedidas++; // Aumenta o Contador de dicas, para o usuário nao pedir mais dicas que a palavra possua.
                                    erro += 5; //Conta um erro para o final do jogo.
                                }
                            }

                            else // Se a letra digitada nao estiver certa e nem for F2, é uma errada.
                            {
                                LetraIncorreta(contadorletraerrada, tecla1); // O método realiza o método de letra errada.
                                contadorletraerrada += 2; // Aumenta o contador da letra errada, para criar um espaço na linha de errados.
                                erro += 5; // Conta um erro para o final do jogo.
                            }

                        }
                        #endregion
                    }
                }
                tempodecorrido = Math.Truncate(DateTime.Now.Subtract(inicio).TotalSeconds) + erro; //Calcula a variação de tempo do inicio do jogo até o tempo atual.
                FinalDoJogo(tempodecorrido, animacao); // Faz a parte final da rodada( muda a animação, escreve na tela, muda o tempo, etc...).

            }
            while (tempodecorrido < 60 && ganhou == false); // Loop enquanto o usuário não tenha perdido ou ganhado.
            GanhouOuPerdeu(ganhou); // Verifica se o usuário perdeu ou ganhou e escreve na tela.
        }

        /// <summary>
        ///  Esse método é utilizado quando o usuário digita uma letra que existe na palavra sorteada. 
        /// </summary>
        /// <param name="LetraPorLetra"></param>
        /// <param name="tecla1"></param>
        /// <param name="contadorletracerta"></param>
        /// <returns></returns>
        static int LetraCorreta(string[] LetraPorLetra, string tecla1, int contadorletracerta)
        {
            int auxiliarletracerta = 0; // variavel criada para devolver quantas letras apertadas tem na palavra.
            for (int n = 0; n < LetraPorLetra.Length; n++)// for para verificar letra por letra da palavra escolhida.
            {
                if (tecla1 == LetraPorLetra[n]) // se a letra digitada for igual a posicao na palavra(estiver certa) adiciona um acerto.
                {
                    if (auxiliarletracerta == 0) // se for a primeira vez que a letra esta certa.
                    {
                        Console.CursorTop = 21; // colcoa na linha das letrascertas.
                        Console.CursorLeft = 16 + contadorletracerta; // coloca na posicao depois da ultima letra certa cadastrada.
                        Console.Write(tecla1); // escreve a letra digitada.
                    }

                    Console.CursorTop = 23; // posiciona o cursor na linha da palavra.
                    Console.CursorLeft = 8 + n + n; // posiciona o cursor aonde a letra correta deveria estar.
                    Console.Write(tecla1);  // substitui o underline pela letra digitada.
                    auxiliarletracerta++; // adicionando o acerto para verificar se faltam letras serem acertadas.
                }


            }
            return auxiliarletracerta; // Retornara o numero de vezes que a letra digitada aparece na frase, logo, que ele acertou.
        }

        /// <summary>
        /// Esse método é utilizado quando o usuário digita uma letra que não existe na palavra.
        /// </summary>
        /// <param name="contadorletraerrada"></param>
        /// <param name="tecla1"></param>
        static void LetraIncorreta(int contadorletraerrada, string tecla1)
        {
            Console.CursorTop = 20;// posiciona o cursor na linha de letras erradas.
            Console.CursorLeft = 16 + contadorletraerrada; // posiciona o cursor na posicao respectivia das quantidade de letras erradas.
            Console.Write(tecla1); // escreve a letra digitada que foi errada.

        }

        /// <summary>
        /// Esse método é utilizado quando o usuário pede uma dica(F2).
        /// </summary>
        /// <param name="contadordicaspedidas"></param>
        /// <param name="linhadadica"></param>
        /// <param name="palavraescolhida"></param>
        /// <returns>O método retorna o valor inteiro da linha que a dica deve ser digitada OU negativo se nao tiver mais dicas.</returns>
        static int DicaPedida(int contadordicaspedidas, int linhadadica, int palavraescolhida)
        {
            // se ele pediu uma dica e estiver a quantidade for menor que a quantidade de dicas da respectiva palavra.
            if (contadordicaspedidas < vetor[palavraescolhida].numerodedicas && linhadadica >= 0)
            {
                if (linhadadica < 3) // se a linha que a dica estiver posicionada for menor que 3, ele posiciona uma linha abaixo.
                {
                    Console.CursorTop = 15 + linhadadica;
                    Console.CursorLeft = 0; // posiciona o cursor no comeco da linha disponivel e apaga oq estava escrito.
                    Console.Write("                                                        ");
                    Console.CursorLeft = 0; // posiciona o cursor no comeco da linha disponivel e digita a dica.
                    Console.Write("Dica:" + vetor[palavraescolhida].dicas[contadordicaspedidas]);
                }
                else if (linhadadica == 3) // se a linha for igual a 3, o espaco para dicas acabou e tem que retornar para o comeco.
                {
                    linhadadica = 0; // ele posiciona o cursor na primeira linha reservada para dicas e apaga oq estiver escrito nela.
                    Console.CursorTop = 15;
                    Console.CursorLeft = 0;
                    Console.Write("                                                        ");
                    Console.CursorLeft = 0; // escreve a respectiva dica da palavra.
                    Console.Write("Dica: " + vetor[palavraescolhida].dicas[contadordicaspedidas]);
                }
                return ++linhadadica; // retorna a proxima linha que a dica deve ser escrita.
            }
            else // Se nao tiver mais dicas disponiveis para essa palavra ele escreve que nao tem dicas disponiveis para essa palavra.
            {
                Console.CursorTop = 14;
                Console.CursorLeft = 0;
                Console.Write("                       ");
                Console.CursorLeft = 0;
                Console.Write("Dicas Indisponiveis");
                return -1; // ao retornar -1 significa que o tempo da pessoa nao vai cair por ter tentado pedir uma dica.
            }
        }

        /// <summary>
        /// Esse método é utilizado para conferir se o usuário ganhou ou nao o jogo da forca com a ultima letra acertada.
        /// </summary>
        /// <param name="letrasacertadas"></param>
        /// <param name="palavraescolhida"></param>
        /// <returns>Esse método retorna true quando o usuário tiver ganhado o jogo e false quando nao.</returns>
        static bool Ganhou(int letrasacertadas, int palavraescolhida)
        {
            // se a quantidade de letras que ele acertou for igual ao numeros de letras que ele precisa acertar, ele ganha.
            if (letrasacertadas == vetor[palavraescolhida].palavra.Length)
                return true; // retorna true para caso ele tenha ganhado o jogo e precisa aparecer a tela de vitoria.

            return false; // retorna false para continuar no Loop ate o tempo acabar.
        }

        /// <summary>
        /// Esse método é chamado ao final de cada palavra para perguntar se o usuário deseja jogar novamente.
        /// </summary>
        /// <param name="sairdojogo"></param>
        /// <param name="perguntafeita"></param>
        /// <returns>O método retorna true para caso o usuário queira sair ou false para jogar novamente.</returns>
        static bool Desejasair(bool sairdojogo, bool perguntafeita)
        {
            if (perguntafeita == false) // Ele so entra nesse metodo se alguma pergunta nao foi feita anteriormente.
            {
                bool validadorsaida = false; // variavel criada para 
                bool validadorbreak = false; // variavel criada para quebrar o Loop.
                if (sairdojogo == false) //so entra nesse if caso o valor da variavel seja falso, para evitar perguntas desnecessarias.
                {
                    do // Loop criado para ate a pessoa digitar um valor correto de sair ou continuar.
                    {
                        validadorsaida = false;
                        try // Controle de excecao para caso o usuario digita algo que nao possa ser convertido para char.
                        {
                            Console.WriteLine("\n\nVoce deseja jogar com outra palavra?[S/N]");
                            char sair = Convert.ToChar(Console.ReadLine());
                            if (sair == 'N' || sair == 'n')
                                validadorsaida = true; // se o usuario quiser sair ele retorna true para sair totalmente do jogo.
                            validadorbreak = true; // se chegou ate aqui, passou pelo controle de excecao e pode continuar com o codigo.
                        }
                        catch // Controle de excecao para o usuario digitar somente as letras informadas.
                        {
                            Console.WriteLine("Digite 'S' para continuar ou 'N' para parar.");
                        }
                    }
                    while (validadorbreak == false);
                    Console.Clear();
                    return validadorsaida; // retornara o valor da resposta do usuario.
                }
                else // caso sair do jogo seja true, ele retorna true automaticamente, porque a pergunta ja foi feita antes.
                {
                    Console.Clear();
                    return true;
                }

            }
            else
                Console.Clear();
            return sairdojogo; // se a pergunta ja foi feita, ele vai retornar o mesmo valor que recebeu da pergunta anterior.
        }

        /// <summary>
        /// Esse método é chamado quando todas as palavras foram jogadas e pergunta se o usuário deseja jogar todas novamente.
        /// </summary>
        /// <param name="sairdojogo"></param>
        /// <param name="contadorpalavras"></param>
        /// <returns>O método retorna true para jogar novamente ou false para parar de jogar.</returns>
        static bool RecomeçarJogo(bool sairdojogo, int contadorpalavras)
        {
            try // controle de excecao criado para caso o usuario digite algo diferente de um char.
            {
                Console.WriteLine("\n\n Voce Deseja jogar todas as palavras novamente?[S/N]");
                char resposta = Convert.ToChar(Console.ReadLine());
                if (resposta == 'N' || resposta == 'n') // se ele nao deseja jogar novamente, sair do jogo vira true.
                    sairdojogo = true;
                else // caso queira jogar novamente, sair do jogo e false.
                    sairdojogo = false;
            }
            catch // controle de excecao para avisar o usuario que so se deve usar as letras indicadas.
            {
                Console.WriteLine("Digite 'S' para continuar ou 'N' para parar.");
            }
            if (sairdojogo == false)// se o usuario deseja jogar todas as palavras novamente, ele zera todos os ForamJogados.
            {
                for (int i = 0; i < contadorpalavras; i++) // passa por todas as posicoes do vetor e diz que as palavras nao foram jogadas ainda.
                {
                    vetor[i].foijogado = false;
                }
            }
            Console.Clear();
            return sairdojogo;// retorna a variavel se ele quer sair ou nao.
        }

        /// <summary>
        /// Esse método lê o arquivo texto e colocar as palavras devidamente em suas posiçoes.
        /// </summary>
        /// <param name="contadorpalavras"></param>
        /// <returns>O método retorna o número de palavras.</returns>
        static int TxtParaVetor(int contadorpalavras)
        {
            int contadordicas = 0;
            foreach (string linha in File.ReadLines("jogo.txt")) // Foreach para ler cada linha do arquivo texto
            {

                if (linha.Contains("P:"))// Se a linha comecar com P: ele salva ela como palvra
                {
                    contadorpalavras++; // muda a posicao que serao gravadas no vetor. 
                    vetor[contadorpalavras] = new PalavrasEDicas(); // cria uma nova posicao no vetor.
                    vetor[contadorpalavras].palavra = linha.Substring(2); // tira o "P:" e salva na posicao palavra.
                    vetor[contadorpalavras].dicas = new string[10]; // cria um novo vetor para armazenar as dicas.
                    vetor[contadorpalavras].foijogado = false; // coloca que a palavra nao foi jogada nenhuma vez ate o momento.
                    contadordicas = 0;
                }
                else if (linha.Contains("D:"))// Se a linha comecar com D: ele salva como dica para a palavra cadastrada acima.
                {
                    vetor[contadorpalavras].dicas[contadordicas] = linha.Substring(2); // tira o "D:" e salva como dica na posicao do contador.
                    contadordicas++; // aumenta o contadorpara salvar a dica em uma posicao diferente.
                    vetor[contadorpalavras].numerodedicas++; // aumenta em um quantas dicas foram salvas para essa palavra.
                }
            }
            return contadorpalavras;
        }

        /// <summary>
        /// Esse é o método inicial do programa, responsavel por chamar os outros métodos.
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            int contadorpalavras = -1,contadorjogadas = 0;
            Random rnd = new Random();

            Entrada(); // Escreve a tela de inicio e espera a confirmação do usuário para continuar.
            ValidadorArquivo(); // Procura o arquivo texto e espera ele ser criado, caso nao encontre.              
            contadorpalavras = TxtParaVetor(contadorpalavras); // Método chamado para armazenar o arquivo texto no vetor.

            bool sairdojogo = false; // variavel utilizada para perguntar se o usuario deseja jogar novamente com outra palavra.
            bool perguntafeita = false; // variavel utilizada para perguntar se o usuario deseja jogar com todas as palvras novamente ou sair do jogo.
            contadorpalavras++;
            do
            {
                perguntafeita = false; // variavel utilizada para nao perguntar duas vezes seguidas se o usuario deseja jogar ou sair.
                sairdojogo = false;
                int palavraescolhida = SorteioDePalavra(contadorpalavras, contadorjogadas); // sorteia um numero que sera a palavra jogada.
                if (palavraescolhida < 0) // ao retornar -1 significa que todas as palavras foram jogadas.
                {
                    sairdojogo = RecomeçarJogo(sairdojogo, contadorpalavras); // metodo utilizado para ver se a pessoa deseja recomeçar o jogo.
                    perguntafeita = true;
                    contadorjogadas = 0;
                }
                else // palavra valida e sera jogada
                {
                    ComecoDoJogo(palavraescolhida); // metodo utilizado para escrever as palavras fixas na tela.
                    HoraDeJogar(palavraescolhida); // Jogo em si, com a palavra sorteada.
                    contadorjogadas++; //aumenta em 1 as vezes que a pessoa jogou.
                }
                sairdojogo = Desejasair(sairdojogo, perguntafeita); // metodo utilizado para saber se a pessoa deseja jogar novamente.
            }
            while (sairdojogo == false);

        }

    }
}
