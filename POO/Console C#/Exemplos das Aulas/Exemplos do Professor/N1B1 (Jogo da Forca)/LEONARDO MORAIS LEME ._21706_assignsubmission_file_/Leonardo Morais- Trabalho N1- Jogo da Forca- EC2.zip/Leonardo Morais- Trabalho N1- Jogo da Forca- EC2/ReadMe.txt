O programa funciona ligado com o arquivo texto chamado "jogo" presente na pasta debug do programa.
Caso queira cadastrar uma palavra nova ou fazer modifica��es nas dicas, fa�a-as manualmente.
Caso queira apenas jogar o programa, n�o veja o arquivo texto, para n�o descobrir as palavras.

Quando o jogo come�ar, as letras certas aparecer�o na palavra sorteada;
Para pedir dicas aperte o bot�o F2;
Caso voce tenha errado uma letra ou pedido uma dica, o seu tempo diminuir� 5 sesgundos!

Bom Jogo!!!