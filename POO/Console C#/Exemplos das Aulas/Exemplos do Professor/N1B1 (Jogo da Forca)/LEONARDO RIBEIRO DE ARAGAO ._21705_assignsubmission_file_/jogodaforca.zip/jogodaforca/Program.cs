﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.IO;

namespace jogodaforca
{
    class Program
    {

        static Palavra[] PalavrasDoJogo;
        static Palavra PalavraAtual;
        static bool[] PosicaoDescoberta;
        static bool Vitoria;
        static int vida;
        static int TempoTotal = 20000;
        static int TempoRestante = 20000;        

        struct Palavra
        {
            public string[] Dicas;
            public string Texto;
        }

        static Palavra[] PegarPalavrasDoArquivo(string caminho)
        {
            Palavra[] palavras;
            string[] linhas = File.ReadAllLines(caminho);
            int qntPalavras = 0;

            // conta quantas palavras existem
            for (int i = 0; i < linhas.Length; i++)
            {
                if (linhas[i].Contains("P:"))
                    qntPalavras++;
            }

            palavras = new Palavra[qntPalavras];

            int linha = 1;
            // conta quantas dicas existem para cada palavra
            for (int i = 0; i < palavras.Length; i++)
            {
                int dicas = 0;

                while (true)
                {
                    if ((linha + 1) > linhas.Length || linhas[linha++].Contains("P:"))
                        break;

                    dicas++;
                }

                palavras[i].Dicas = new string[dicas];
            }

            linha = 0;

            // preenche as variaveis da palavra
            for (int i = 0; i < palavras.Length; i++)
            {
                palavras[i].Texto = linhas[linha++].Replace("P:", "");

                for (int j = 0; j < palavras[i].Dicas.Length; j++)
                {
                    palavras[i].Dicas[j] = linhas[linha++].Replace("D:", "");
                }
            }

            return palavras;
        }

        static string PegarTextoVisivel(Palavra plv)
        {
            string texto = "";

            for (int i = 0; i < plv.Texto.Length; i++)
                if (PosicaoDescoberta[i] == false)
                    texto += "_";                               //Se a letra ainda não foi descoberta, adicionamos um "_" ao texto.
                else
                    texto += char.ToUpper(plv.Texto[i]);        //Se a letra já foi descoberta, adicionamos ela ao texto.



            return texto;
        }        

        static void MostrarLetra(char letra)
        {
            for (int i = 0; i < PalavraAtual.Texto.Length; i++)
                if (char.ToUpper(PalavraAtual.Texto[i]) == char.ToUpper(letra))
                    PosicaoDescoberta[i] = true;                //Se a letra existe no texto, sua visibilidade é marcada como "true" no array de posições descobertas.
        }

        static void ReescreveTudo(int contaDicas, int vida)
        {
            Console.Write("Palavra:");
            Console.Write("\tDigite F2 para obter uma dica");
            Console.WriteLine("\t\tVida: {0}", vida);
            Console.WriteLine("\n" + PegarTextoVisivel(PalavraAtual));
            for (int o = 0; o < contaDicas; o++)
            {
                try
                {
                    Console.WriteLine("\nDica:" + PalavraAtual.Dicas[o] + "  ");
                }
                catch
                {
                    Console.WriteLine("\nNão há mais dicas");
                }
            }
        }

        static void Contador(object args)
        {
            string msg = "";

            if (TempoRestante >= 0)
            {

                TempoRestante -= 1000;
                Console.CursorLeft = 50;
                Console.CursorTop = 20;
                TimeSpan t = TimeSpan.FromMilliseconds(TempoRestante);
                string tempo = t.ToString(@"ss");
                msg = "Tempo restante: " + tempo;
                Console.WriteLine(msg);
                if (TempoRestante <= 0)
                {
                    vida = vida - 1;
                    TempoRestante = TempoTotal;
                    if (vida == 0)
                    {
                        msg = "";
                    }


                }
            }
            


        }



        public static void Main(string[] args)
        {

            Console.WriteLine("Nome: Leonardo Aragão \nRA:081170011 \nPartes Desenvolvidas: \nJogo [X] \nDicas [X] \nTempo[X]");
            string resp;
            vida = 6;

            do
            {

                do
                {
                    Console.WriteLine("\nDeseja jogar? <s/n> ");
                    resp = Console.ReadLine();
                    Console.Clear();                    
                }
                while (resp.ToUpper() != "N" && resp.ToUpper() != "S");

                if (char.ToLower (resp[0]) == 'n')
                    break;


                PalavrasDoJogo = PegarPalavrasDoArquivo("jogo.txt");

                Random r = new Random();
                PalavraAtual = PalavrasDoJogo[r.Next(PalavrasDoJogo.Length)];
                PosicaoDescoberta = new bool[PalavraAtual.Texto.Length];
                Vitoria = false;


                
                int contaDicas = 1;
                Timer t = new Timer(Contador, null, 1000, 1000);

                do
                {
                    
                    Console.Clear();                    
                    ReescreveTudo(contaDicas, vida);                    
                    ConsoleKeyInfo entrada = Console.ReadKey();
                    



                    if (entrada.Key.ToString() == "F2")
                    {
                        contaDicas++;
                        vida--;
                    }                    
                    else
                    {
                        if (char.IsLetter(entrada.KeyChar))
                        {
                            if (PalavraAtual.Texto.ToUpper().Contains(char.ConvertFromUtf32(entrada.KeyChar).ToUpper()))
                                MostrarLetra(entrada.KeyChar);
                            else
                                vida--;
                        }
                    }

                    

                    if (!PegarTextoVisivel(PalavraAtual).Contains("_"))
                        Vitoria = true;
                }
                while (vida > 0 && !Vitoria);
                t.Change(Timeout.Infinite, Timeout.Infinite);
                vida = 6;


                Console.Clear();
                if (vida <= 0)
                    Console.WriteLine("Você perdeu!");

                else if (Vitoria)
                    Console.WriteLine("Você venceu!");


            }
            while (resp.ToUpper() != "N");




        

        }
    }
}
