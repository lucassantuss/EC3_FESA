﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Threading;

namespace Jogo_da_Forca
{
    class Program
    {
        #region Declaração de variáveis

        // Declaração do Struct
        public struct Palavras
        {
            public string palavra;
            public string[] dicas;
        }

        #endregion

        #region Variáveis para execução

        // Abre arquivo
        static string[] arquivo = LerArquivo();

        // Cursor para o Array de Struct
        static int posicaoPalavras = 0;

        // Conta quantas palavras tem dentro do arquivo
        static int totalPalavras = ContaPalavras(arquivo);

        // Verifica quais posições do array tem palavras
        static int[] posicoes = IndexPalavras(arquivo);
        static int cursorPosicoes = 0;

        // Identifica qual a última posição do array que tem uma palavra
        static int posicaoUltimaPalavra = posicoes[posicoes.Length - 1];

        #endregion

        #region Métodos
        /// <summary>
        /// Lê o arquivo e informa caso o mesmo não exista
        /// </summary>
        /// <returns></returns>
        public static string[] LerArquivo()
        {
            // Controle de exceção
            try
            {
                // Lê o arquivo e posiciona as linhas em um vetor
                string[] textoArquivo = File.ReadAllLines("jogo.txt");
                return textoArquivo;

            }
            catch (Exception e)
            {
                // Retorna erro caso o arquivo não exista na pasta Debug
                Console.WriteLine("O arquivo não existe.");
                string[] erro = new string[1];
                erro[0] = "!ERROR!";
                return erro;
            }

        }

        /// <summary>
        /// Contabiliza o número de palavras presentes no arquivo
        /// </summary>
        /// <param name="arquivo"></param>
        /// <returns></returns>
        public static int ContaPalavras(string[] arquivo)
        {
            int resultado = 0;

            for (int i = 0; i < arquivo.Length; i++)
            {
                if (arquivo[i].Substring(0, 2) == "P:")
                    resultado++;
            }

            return resultado;
        }

        /// <summary>
        /// Acrescenta em + 1 a posiçãoAtualArray
        /// </summary>
        /// <param name="arquivo"></param>
        /// <returns></returns>
        public static int[] IndexPalavras(string[] arquivo)
        {
            int[] resultado = new int[ContaPalavras(arquivo)];

            int posicaoAtualArray = 0;

            for (int i = 0; i < arquivo.Length; i++)
            {
                if (arquivo[i].Substring(0, 2) == "P:")
                {
                    resultado[posicaoAtualArray] = i;
                    posicaoAtualArray++;
                }
            }

            return resultado;
        }

        /// <summary>
        ///  Sorteia uma Struct, impedindo que Structs repetidas sejam selecionadas
        /// </summary>
        /// <param name="todasPalavras"></param>
        /// <param name="palavrasJogadas"></param>
        /// <returns></returns>
        public static Palavras SelecionarPalavra(Palavras[] todasPalavras, string[] palavrasJogadas)
        {
            Palavras selecionada = new Palavras();
            bool novaPalavra = false;

            while (!novaPalavra)
            {
                Random rnd = new Random();
                int idSelecionado = rnd.Next(0, todasPalavras.Length);
                selecionada = todasPalavras[idSelecionado];

                for (int i = 0; i < palavrasJogadas.Length; i++)
                {
                    if (selecionada.palavra == palavrasJogadas[i])
                    {
                        novaPalavra = false;
                        break;
                    }
                    novaPalavra = true;
                }
            }
            return selecionada;
        }

        /// <summary>
        /// Posiciona o cursor em um luga fixo da tela
        /// </summary>
        public static void PosicionaCursornaTela()
        {
            Console.CursorTop = 9;
            Console.CursorLeft = 5;
            Console.Write("Letra digitada: ");     
        }

        /// <summary>
        /// Animação do jogo
        /// </summary>
        /// <param name="erros"></param>
        public static void Animacao(int erros)
        {
            if (erros == 1)
            {
                Console.CursorTop = 0;
                Console.CursorLeft = 0;
                Console.WriteLine("┌────────┐" +
                    "\n|        O" +
                    "\n|" +
                    "\n|" +
                    "\n|" +
                    "\n|");
                PosicionaCursornaTela();
            }
            else if (erros == 2)
            {
                Console.CursorTop = 0;
                Console.CursorLeft = 0;
                Console.WriteLine("┌────────┐" +
                    "\n|        O" +
                    "\n|        |" +
                    "\n|" +
                    "\n|" +
                    "\n|\n");
                PosicionaCursornaTela();
            }
            else if (erros == 3)
            {
                Console.CursorTop = 0;
                Console.CursorLeft = 0;
                Console.WriteLine("┌────────┐"
                   + "\n|        O"
                   + "\n|       /| "
                   + "\n|"
                   + "\n|"
                   + "\n|\n");
                PosicionaCursornaTela();
            }
            else if (erros == 4)
            {
                Console.CursorTop = 0;
                Console.CursorLeft = 0;
                Console.WriteLine("┌────────┐"
                   + "\n|        O"
                   + "\n|       /||"
                   + "\n|"
                   + "\n|"
                   + "\n|\n");
                PosicionaCursornaTela();
            }
            else if (erros == 5)
            {
                Console.CursorTop = 0;
                Console.CursorLeft = 0;
                Console.WriteLine("┌────────┐"
                   + "\n|        O"
                   + "\n|       /||"
                   + "\n|       /  "
                   + "\n|"
                   + "\n|\n");
                PosicionaCursornaTela();
            }
            else if (erros == 6)
            {
                Console.CursorTop = 0;
                Console.CursorLeft = 0;
                Console.WriteLine("┌────────┐"
                   + "\n|        O"
                   + "\n|       /||"
                   + "\n|       / |"
                   + "\n|"
                   + "\n|\n");
                PosicionaCursornaTela();
            }
        }

        #endregion

        static void Main(string[] args)
        {

            #region Associação de informações
            // Cria um array de palavras e dicas, cujo tamanho equivale ao total de palavras no arquivo
            Palavras[] palavras = new Palavras[totalPalavras];

            for (int i = 0; i < posicoes.Length; i++)
            {
                palavras[posicaoPalavras].palavra = arquivo[posicoes[i]].Substring(2);

                cursorPosicoes++;

                int tamanhoArrayDicas;
                if (cursorPosicoes <= posicoes.Length - 1)
                    tamanhoArrayDicas = posicoes[cursorPosicoes] - posicoes[cursorPosicoes - 1] - 1;
                else
                    tamanhoArrayDicas = (arquivo.Length - 1) - posicoes[cursorPosicoes - 1];

                palavras[posicaoPalavras].dicas = new string[tamanhoArrayDicas];

                int posicaoArrayDicas = 0;

                for (int j = posicoes[cursorPosicoes - 1] + 1; j < (cursorPosicoes <= posicoes.Length - 1 ? posicoes[cursorPosicoes] : (arquivo.Length)); j++)
                {
                    palavras[posicaoPalavras].dicas[posicaoArrayDicas] = arquivo[j].Substring(2);

                    posicaoArrayDicas++;
                }
                posicaoPalavras++;
            }
            #endregion

            string[] palavrasJogadas = new string[totalPalavras];
            int rodadas = 0;
            Console.Clear();
            Console.Write("Letícia Jordão     RA: 081170044\nJOGO [x]\nDICAS [x]\nCONTROLE DE TEMPO [x]");
            Console.ReadLine();
            #region
            do
            {
                #region Execução do Jogo
                #region Variáveis de Início
              
                Console.Clear(); Console.CursorVisible = false;
                int erros = 0, n = 0, acertos = 0, tentativas = 0;
                DateTime inicio = DateTime.Now;
                double tempo = 0;
                Palavras selecionada = SelecionarPalavra(palavras, palavrasJogadas);
                palavrasJogadas[rodadas] = selecionada.palavra;
                Console.CursorTop = +15; Console.CursorLeft = 5;
                Console.WriteLine("Dicas: " + selecionada.dicas[0]);
                string[] charsPressionados = new string[30];
                string[] LetraPorLetra = new string[selecionada.palavra.Length];
                string letraserradas = "";
                Console.CursorTop = 0;
                Console.CursorLeft = 0;
                #endregion
                Console.WriteLine("┌────────┐" +
                        "\n|" +
                        "\n|" +
                        "\n|" +
                        "\n|" +
                        "\n|");
                PosicionaCursornaTela();
                
                Console.CursorTop = 7;
                Console.CursorLeft = 0;
                for (int l = 0; l < selecionada.palavra.Length; l ++) //Substitui os caracteres da palavra por '_'
                {
                    if (" " != Convert.ToString(selecionada.palavra[l]))
                    {
                        LetraPorLetra[l] = Convert.ToString(selecionada.palavra[l]);
                        LetraPorLetra[l] = LetraPorLetra[l].ToUpper();
                        Console.Write("_ ");
                    }
                    else
                    {
                        Console.Write("  ");
                        acertos++;
                    }
                }
               
                    #region Confere Tecla
                    do
                    {
                    if (Console.KeyAvailable) //Espera que o usuário digite uma tecla
                    {
                        ConsoleKeyInfo tecla = Console.ReadKey();
                        string tecla1 = (Convert.ToString(tecla.Key));
                        bool charRepetido = false;

                        for (int i = 0; i < charsPressionados.Length; i++)//Confere se a tecla digitada já foi usada anteriormente
                        {
                            if (tecla1 == charsPressionados[i])
                            {
                                charRepetido = true;
                                break;
                            }
                        }

                        int acertosNaTentativa = 0;

                        if (!charRepetido)
                        {
                            charsPressionados[tentativas] = tecla1;
                            tentativas++;
                            for (int l = 0; l < selecionada.palavra.Length; l++)
                            {
                                if (tecla1 == LetraPorLetra[l])//Verifica e posiciona a letra correta na palavra, acrescenta os acertos
                                {
                                    Console.CursorTop = 7;
                                    Console.CursorLeft = 0 + 2 * l;
                                    Console.WriteLine(tecla1);
                                    ++acertos;
                                    ++acertosNaTentativa;
                                    PosicionaCursornaTela();
                                }
                            }
                            if (acertosNaTentativa == 0 && tecla1 != "F2")//Escreve na tela as letras erradas já tentadas 
                            {
                                letraserradas += tecla1 + "-";
                                Console.CursorTop = +12;
                                Console.CursorLeft = +5;
                                Console.WriteLine("Letras erradas: " + letraserradas.Substring(0));
                                ++erros;
                                PosicionaCursornaTela();
                            }
                        }

                        if (tecla1 == "F2")
                        {
                            ++n;
                            Console.CursorLeft = +5;
                            if (n < selecionada.dicas.Length)//Exibe as dicas relacionadas à palavra
                            {
                                Console.CursorTop = +15 + n;
                                Console.CursorLeft = +12;
                                Console.Write(selecionada.dicas[n]);
                                PosicionaCursornaTela();
                                ++erros;
                            }
                            else //Informa que não há mais dicas para a palavra
                            {
                                Console.CursorTop = +15 + n;
                                Console.CursorLeft = +12;
                                Console.Write("Não há mais dicas");
                                PosicionaCursornaTela();
                            }
                            
                        }
                    }
                    
                    #endregion

                    #region Controle de Tempo
                    tempo = Math.Truncate(DateTime.Now.Subtract(inicio).TotalSeconds);
                    Console.CursorLeft = 30;
                    Console.CursorTop = 5;
                    Console.Write("                            ");
                    Console.CursorLeft = 30;
                    Console.Write("Tempo Restante = {0}", 30 - tempo);
                    Thread.Sleep(200);
                    #endregion

                    Animacao(erros);
                    }
                    while (tempo <= 30 && erros <= 6 && acertos < selecionada.palavra.Length);
                    #endregion
 
                    #region Final
                    Console.Clear();

                    if (acertos == selecionada.palavra.Length) //Informa que o usuário venceu
                    {
                        Console.Write("Você venceu!");
                        Console.Write("\nA palavra sorteada era: " + selecionada.palavra);
                    }
                    else if (tempo > 30 || erros == 7) //Informa que o usuário perdeu
                    {
                        Console.Write("Você perdeu!");
                        Console.Write("\nA palavra sorteada era: " + selecionada.palavra);
                    }
                    Console.Write("\nPara jogar novamente, pressione ENTER");
                    ++rodadas;
                }
                while (rodadas < totalPalavras && Console.ReadKey().Key == ConsoleKey.Enter) ;
                #endregion

                Console.Clear();

                if (rodadas == totalPalavras)
                    Console.Write("Todas as palavras foram jogadas");

               
                Console.ReadLine();
                #endregion

            }   
    }
}
