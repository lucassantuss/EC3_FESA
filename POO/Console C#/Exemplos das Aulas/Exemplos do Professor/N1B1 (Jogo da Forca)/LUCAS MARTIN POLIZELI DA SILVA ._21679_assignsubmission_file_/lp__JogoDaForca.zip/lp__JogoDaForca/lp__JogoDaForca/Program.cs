﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Threading;

namespace lp__JogoDaForca
{
    class Program
    {
        // VARIÁVEIS GLOBAIS
        static Rodada[] jogada = new Rodada[100];
        static ConsoleKeyInfo cki;
        static Random gerador = new Random();
        static int rodada = 0,
                   TempoTotal = 20000,
                   TempoRestante = 20000,
                   qtdErros = 0,
                   dicaDaVez = 0,
                   nRodadaIndiceLeitura = -1;
        static char[] palavraEscondida = new char[20];
        static bool ganhou = false,
                    dicaAcabou = false;

        // DECLARANDO STRUCT
        struct Rodada
        {
            public string palavra;
            public string[] dicas;
            public int qtdDicas;
        }

        // METODOS 
        /// <summary>
        /// O Método abaixo lê as informações do arquivo texto, e faz a separação
        /// do que é dica, e o que é palavra. Além de efetuar a leitura, o método
        /// abaixo armazena a quantidade de dicas que cada palavra tem cadastrado.
        /// </summary>
        static void LeituraDados()
        {
            // Stream Reader 
            StreamReader sr = new StreamReader("jogo.txt");

            // Índices Leitura 
            nRodadaIndiceLeitura = -1;
            int nDicas = 0;
            string letra;

            do
            {
                // Variável Auxiliar
                letra = sr.ReadLine();

                // Verificação se é palavra ou dica 
                if (letra[0] == 'P')
                {
                    nRodadaIndiceLeitura++;
                    jogada[nRodadaIndiceLeitura].dicas = new string[10];
                    jogada[nRodadaIndiceLeitura].palavra = letra.Substring(2).ToUpper();
                    letra = "";
                    nDicas = 0;
                }
                else if (letra[0] == 'D')
                {
                    jogada[nRodadaIndiceLeitura].dicas[nDicas] = letra.Substring(2);
                    nDicas++;
                    jogada[nRodadaIndiceLeitura].qtdDicas = nDicas;
                }
            }
            while (!sr.EndOfStream);
            return;
        }

        /// <summary>
        /// Mostra a dica na tela, caso o usuário já pediu todas as dicas, ele mostra que as dicas acabaram.
        /// </summary>
        static void MostraDica()
        {
            if (!dicaAcabou)
                Console.WriteLine("Dica: {0}", jogada[rodada].dicas[dicaDaVez]);
            else
                Console.WriteLine("Não há mais dicas.");

            return;
        }

        /// <summary>
        /// O método abaixo apenas exibe a palavra escondida na imagem
        /// </summary>
        static void ExibePalavraEscondida()
        {
            for (int i = 0; i < jogada[rodada].palavra.Length; i++)
                Console.Write("{0}  ", palavraEscondida[i]);
            return;
        }

        /// <summary>
        /// Verifica quantas letras tem a palavra, e cria um vetor paralelo a palavra que
        /// será apenas de underlines, ou seja, é a palavra escondida.
        /// </summary>
        static void CriaPalavraEscondida()
        {
            for (int i = 0; i < jogada[rodada].palavra.Length; i++)
                if (jogada[rodada].palavra[i] == ' ')
                    palavraEscondida[i] = ' ';
                else
                    palavraEscondida[i] = '_';
            return;
        }

        /// <summary>
        /// Verifica a letra que o usuário apertou durante o jogo. Caso seja F2, ele mostra a proxima dica. Caso seja letra qualquer
        /// o mesmo verifica se existe alguma letra na palavra da rodada. Se não houver, o método incrementa mais um erro ao usuário. 
        /// </summary>
        static void VerificaLetra()
        {
            if (Console.KeyAvailable)
            {
                cki = Console.ReadKey();

                if (cki.Key.ToString() == "F2")
                {
                    if ((jogada[rodada].qtdDicas - 1) > dicaDaVez)
                    {
                        dicaDaVez++;
                        qtdErros++;
                        dicaAcabou = false;
                    }
                    else
                    {
                        dicaAcabou = true;
                    }
                    return;
                }

                for (int i = 0; i < jogada[rodada].palavra.Length; i++)
                {
                    if (cki.Key.ToString() == jogada[rodada].palavra[i].ToString())
                    {
                        palavraEscondida[i] = char.Parse(cki.Key.ToString());
                        //ResetaTimer();
                    }
                }
                ConteudoTela();
                VerificaErro();
                VerificaGanhou();
            }
            return;
        }

        /// <summary>
        /// Verifica se o usuário errou a letra na rodada. 
        /// </summary>
        static void VerificaErro()
        {
            if (jogada[rodada].palavra.IndexOf(cki.Key.ToString()) == -1)
                qtdErros++;
            return;
        }

        /// <summary>
        /// Atribui a variável do timer (que controla o tempo) o valor inicial da mesma para que possa
        /// dar mais segundos ao usuário que estará jogando, em cada jogada.
        /// </summary>
        static void ResetaTimer()
        {
            TempoRestante = TempoTotal;
            return;
        }

        /// <summary>
        /// Mostra na tela que o usuário perdeu, e a palavra da vez
        /// </summary>
        static void MostraPerdeu()
        {
            Console.WriteLine("VOCÊ MORREU! TENTE NOVAMENTE");
            Console.WriteLine("A palavra era: {0}", jogada[rodada].palavra);
            Console.WriteLine("---------------------------------------------");
            return;
        }

        /// <summary>
        /// Verifica se o usuário ganhou a rodada.
        /// </summary>
        static void VerificaGanhou()
        {
            string palavraDoTxt = "";
            for (int i = 0; i < jogada[rodada].palavra.Length; i++)
                palavraDoTxt = palavraDoTxt + palavraEscondida[i];

            if (palavraDoTxt == jogada[rodada].palavra)
            {

                ganhou = true;
                Console.WriteLine("Parabéns, você ganhou!");
                Console.Write("A palavra era: {0}", jogada[rodada].palavra);

                Console.WriteLine("\n---------------------------------------------");
            }
            else
            {
                ganhou = false;
                return;
            }
            return;

        }

        /// <summary>
        /// Verifica se o usuário perdeu, e mostra que o mesmo, perdeu.
        /// </summary>
        static void VerificaPerdeu()
        {
            if (qtdErros == 6 || TempoRestante <= 0)
                MostraPerdeu();
        }

        /// <summary>
        /// Chama a cada um segundo o método ConteudoTela() que mostra na tela a parte visual.
        /// É um timer, ou seja, conta os segundos para o usuário não perder o jogo.
        /// </summary>
        /// <param name="o">parametro necessário para funcionamento do objeto</param>
        static void Temporizador(object o)
        {
            if (TempoRestante <= 0)
                return;

            if (ganhou)
                return;

            TempoRestante -= 1000;
            ConteudoTela();


            if (TempoRestante <= 0)
                //MostraPerdeu();
                return;
        }

        /// <summary>
        /// Printa o conteúdo na tela sempre que chamado
        /// </summary>
        static void ConteudoTela()
        {
            Console.Clear();
            switch (qtdErros)
            {
                case 0:
                    Console.Clear();
                    Console.WriteLine("---------------------------------------------");
                    Console.WriteLine("          BEM-VINDO AO JOGO DA FORCA.");
                    Console.WriteLine("---------------------------------------------\n");
                    Console.WriteLine(" __________________________________________\n" +
                                      "              ,--.                    ,--. \n" +
                                      "               \\  `                  |oo  |\n" +
                                      "   o  o  o  o  /   ;  o  o  o  o  o  |~~  |\n" +
                                      "              '._,'                  |/\\/\\|\n" +
                                      " __________________________________________\n");
                    Console.WriteLine("---------------------------------------------");
                    Console.WriteLine("             Você tem {0} segundos", (TempoRestante / 1000));
                    Console.WriteLine("---------------------------------------------");
                    //TempoRestante -= 1000;
                    Console.Write("Palavra: ");
                    ExibePalavraEscondida();
                    Console.WriteLine("\n---------------------------------------------");
                    MostraDica();
                    Console.WriteLine("---------------------------------------------");
                    Console.Write("Digite uma letra: ");
                    Console.WriteLine("\n---------------------------------------------");
                    break;

                case 1:
                    Console.Clear();
                    Console.WriteLine("---------------------------------------------");
                    Console.WriteLine("          BEM-VINDO AO JOGO DA FORCA.");
                    Console.WriteLine("---------------------------------------------\n");
                    Console.WriteLine(" __________________________________________\n" +
                                      "              ,--.                ,--.     \n" +
                                      "               \\  `              |oo  |    \n" +
                                      "   o  o  o  o  /   ;  o  o  o  o |~~  | o  \n" +
                                      "              '._,'              |/\\/\\|    \n" +
                                      " __________________________________________\n");
                    Console.WriteLine("---------------------------------------------");
                    Console.WriteLine("             Você tem {0} segundos", (TempoRestante / 1000));
                    Console.WriteLine("---------------------------------------------");
                    //TempoRestante -= 1000;
                    Console.Write("Palavra: ");
                    ExibePalavraEscondida();
                    Console.WriteLine("\n---------------------------------------------");
                    MostraDica();
                    Console.WriteLine("---------------------------------------------");
                    Console.Write("Digite uma letra: ");
                    Console.WriteLine("\n---------------------------------------------");
                    break;
                case 2:
                    Console.Clear();
                    Console.WriteLine("---------------------------------------------");
                    Console.WriteLine("          BEM-VINDO AO JOGO DA FORCA.");
                    Console.WriteLine("---------------------------------------------\n");
                    Console.WriteLine(" __________________________________________\n" +
                                      "              ,--.             ,--.      \n" +
                                      "               \\  `           |oo  |     \n" +
                                      "   o  o  o  o  /   ;  o  o  o |~~  | o  o\n" +
                                      "              '._,'           |/\\/\\|     \n" +
                                      " __________________________________________\n");
                    Console.WriteLine("---------------------------------------------");
                    Console.WriteLine("             Você tem {0} segundos", (TempoRestante / 1000));
                    Console.WriteLine("---------------------------------------------");
                    //TempoRestante -= 1000;
                    Console.Write("Palavra: ");
                    ExibePalavraEscondida();
                    Console.WriteLine("\n---------------------------------------------");
                    MostraDica();
                    Console.WriteLine("---------------------------------------------");
                    Console.Write("Digite uma letra: ");
                    Console.WriteLine("\n---------------------------------------------");
                    break;

                case 3:
                    Console.Clear();
                    Console.WriteLine("---------------------------------------------");
                    Console.WriteLine("          BEM-VINDO AO JOGO DA FORCA.");
                    Console.WriteLine("---------------------------------------------\n");
                    Console.WriteLine(" __________________________________________\n" +
                                      "              ,--.          ,--.           \n" +
                                      "               \\  `        |oo  |          \n" +
                                      "   o  o  o  o  /   ;  o  o |~~  | o  o  o  \n" +
                                      "              '._,'        |/\\/\\|          \n" +
                                      " __________________________________________\n");
                    Console.WriteLine("---------------------------------------------");
                    Console.WriteLine("             Você tem {0} segundos", (TempoRestante / 1000));
                    Console.WriteLine("---------------------------------------------");
                    //TempoRestante -= 1000;
                    Console.Write("Palavra: ");
                    ExibePalavraEscondida();
                    Console.WriteLine("\n---------------------------------------------");
                    MostraDica();
                    Console.WriteLine("---------------------------------------------");
                    Console.Write("Digite uma letra: ");
                    Console.WriteLine("\n---------------------------------------------");
                    break;

                case 4:
                    Console.Clear();
                    Console.WriteLine("---------------------------------------------");
                    Console.WriteLine("          BEM-VINDO AO JOGO DA FORCA.");
                    Console.WriteLine("---------------------------------------------\n");
                    Console.WriteLine(" __________________________________________\n" +
                                      "              ,--.       ,--.              \n" +
                                      "               \\  `     |oo  |             \n" +
                                      "   o  o  o  o  /   ;  o |~~  | o  o  o  o  \n" +
                                      "              '._,'     |/\\/\\|             \n" +
                                      " __________________________________________\n");
                    Console.WriteLine("---------------------------------------------");
                    Console.WriteLine("             Você tem {0} segundos", (TempoRestante / 1000));
                    Console.WriteLine("---------------------------------------------");
                    //TempoRestante -= 1000;
                    Console.Write("Palavra: ");
                    ExibePalavraEscondida();
                    Console.WriteLine("\n---------------------------------------------");
                    MostraDica();
                    Console.WriteLine("---------------------------------------------");
                    Console.Write("Digite uma letra: ");
                    Console.WriteLine("\n---------------------------------------------");
                    break;

                case 5:
                    Console.Clear();
                    Console.WriteLine("---------------------------------------------");
                    Console.WriteLine("          BEM-VINDO AO JOGO DA FORCA.");
                    Console.WriteLine("---------------------------------------------\n");
                    Console.WriteLine(" __________________________________________\n" +
                                      "              ,--.    ,--.                 \n" +
                                      "               \\  `  |oo  |                \n" +
                                      "   o  o  o  o  /   ; |~~  | o  o  o  o  o  \n" +
                                      "              '._,'  |/\\/\\|                \n" +
                                      " __________________________________________\n");
                    Console.WriteLine("---------------------------------------------");
                    Console.WriteLine("             Você tem {0} segundos", (TempoRestante / 1000));
                    Console.WriteLine("---------------------------------------------");
                    //TempoRestante -= 1000;
                    Console.Write("Palavra: ");
                    ExibePalavraEscondida();
                    Console.WriteLine("\n---------------------------------------------");
                    MostraDica();
                    Console.WriteLine("---------------------------------------------");
                    Console.Write("Digite uma letra: ");
                    Console.WriteLine("\n---------------------------------------------");
                    break;
            }
        }

        static void Main(string[] args)
        {
            // Chamando método que lê os dados do arquivo de texto
            LeituraDados();

            // Elementos visuais da parte inicial 
            Console.WriteLine("                     Faculdade de Tecnologia Termomecanica\n" +
                              "                                N1 de Algorítmos II\n" +
                              "                     Nome: Lucas Martin Polizeli da Silva\n" +
                              "                                RA: 081170029\n\n" +
                              "                         ---------------------------\n" +
                              "                         BEM-VINDO AO JOGO DA FORCA.\n" +
                              "                         ---------------------------\n" +
                              "\nJOGO [X] >>>>> 6 pontos.\n" +
                              "DICAS[X] >>>>> 2 pontos.\n" +
                              "CONTROLE DE TEMPO[X] >>>>> 2 pontos.\n" +
                              "\nPressione uma tecla para continuar... ");


            // Pausa para começar o jogo
            Console.ReadKey();
            Console.Clear();
            char respContinue = ' ';
            do
            {
                rodada = gerador.Next(0, nRodadaIndiceLeitura);
                CriaPalavraEscondida();
                Timer t = new Timer(Temporizador, null, 1000, 1000);

                while (qtdErros < 6 && TempoRestante > 0 && !ganhou)
                {
                    VerificaLetra();
                }

                t.Dispose();
                VerificaPerdeu();
                ResetaTimer();

                qtdErros = 0;
                ganhou = false;
                dicaAcabou = false;

                Thread.Sleep(2000);

                bool foi = false;
                do
                {
                    try
                    {
                        Console.Write("Deseja jogar novamente? <S/N>");
                        respContinue = char.Parse(Console.ReadLine().ToUpper());
                        foi = true;
                    }
                    catch
                    {
                        Console.WriteLine("Digite apenas <S para continuar/Qualquer outra coisa para sair>.");
                        foi = false;
                    }
                }
                while (!foi);
            } while (respContinue == 'S');

        }
    }
}
