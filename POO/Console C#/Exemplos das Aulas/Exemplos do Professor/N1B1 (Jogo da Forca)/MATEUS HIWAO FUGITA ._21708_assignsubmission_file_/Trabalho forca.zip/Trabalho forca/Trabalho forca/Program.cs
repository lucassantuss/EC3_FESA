﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Threading;

namespace Trabalho_forca
{
    class Program
    {
        static string palavraSorteada;
        static int erros, acertos;
        static char resposta, acabou;
        static int numeroSorteado; //número sorteado        
        static int tentativas; //
        static string letraMaiuscula; //converte a letra digitada pelo usuário em letra maiúscula                
        static int apertouF2;
        static int[] numerosSorteados; //guarda os números sorteados (para escolher a palavra a ser descoberta)         

        struct Jogo
        {
            public string[] palavras;
            public string[] dicas;
            public int contaPalavras;
            public int contaDicas;
        }

        static Jogo jogo = new Jogo();

        /// <summary>
        /// Apresenta o nome do aluno e o RA
        /// </summary>
        static void Inicio()
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("         JJJJJJJJJJJ     OOO           GGGG           OOO\n" +
                          "              J         O   O         G    G         O   O\n" +
                          "              J        O     O       G      G       O     O\n" +
                          "              J       O       O     G              O       O\n" +
                          "              J       O       O     G     GGGG     O       O\n" +
                          "         J    J        O     O       G     G        O     O\n" +
                          "         J    J         O   O         G   G          O   O\n" +
                          "         JJJJJJ          OOO           GGG            OOO\n" +
                          "\n" +
                          "                     DDDDD            AA                     \n" +
                          "                     D    D          A  A                     \n" +
                          "                     D     D        A    A                     \n" +
                          "                     D      D      A      A                     \n" +
                          "                     D      D     AAAAAAAAAA                     \n" +
                          "                     D     D     A          A                     \n" +
                          "                     D    D     A            A                     \n" +
                          "                     DDDDD     A              A                     \n" +
                          "\n" +
                          "FFFFFFFFFF        OOO        RRRRR          CCCCC            AA\n" +
                          "F                O   O       R    R        C     C          A  A\n" +
                          "F               O     O      R     R      C                A    A\n" +
                          "FFFFFFFFFF     O       O     R     R     C                A      A\n" +
                          "F              O       O     RRRRRR      C               AAAAAAAAAA\n" +
                          "F               O     O      R    R       C             A          A\n" +
                          "F                O   O       R     R       C     C     A            A\n" +
                          "F                 OOO        R      R       CCCCC     A              A\n");
            Console.WriteLine("\n    Nome: Mateus Hiwao Fugita    Nome: João Paulo da Silva Santos");
            Console.Write("          RA: 081170015                 RA: 081170026");
            Console.ReadKey();
            Console.Clear();
        }

        /// <summary>
        /// Mostra as partes feitas do trabalho (jogo, dicas e controle de tempo)
        /// </summary>
        static void Nota()
        {
            Console.Write("JOGO               [ X ] >>>>> 6 pontos.\n" +
                          "DICAS              [ X ] >>>>> 2 pontos.\n" +
                          "CONTROLE DE TEMPO  [   ] >>>>> 2 pontos.\n");
            Console.ReadKey();
            Console.Clear();
        }                

        /// <summary>
        /// Armazena as palavras do arquivo texto em um vetor
        /// </summary>
        /// <param name="linhas"> linhas do arquivo texto </param>
        /// <returns> retorna um vetor com todas as palavras </returns>
        static string[] ArmazenaPalavras(string[] linhas)
        {
            jogo.palavras = new string[100];
            jogo.contaPalavras = 0;
            int P;

            for (int i = 0; i < linhas.Length; i++)
            {
                P = linhas[i].IndexOf("P");

                if (P == 0 && linhas[i].Substring(2) != "")
                {
                    jogo.palavras[jogo.contaPalavras] = linhas[i].Substring(2);
                    jogo.contaPalavras++;
                }
            }
            return jogo.palavras;
        }

        /// <summary>
        /// Armazena as dicas da palavra sorteada em um vetor
        /// </summary>
        /// <param name="numeroSorteado"> número sorteado para selecionar uma palavra do vetor (que será a palavra sorteada) </param>
        /// <param name="linhas"> linhas do arquivo texto </param>
        /// <param name="palavras"> vetor com todas as palavras do arquivo texto </param>
        /// <returns> retorna um vetor com as dicas </returns>
        static string[] ArmazenaDicas(int numeroSorteado, string[] linhas, string[] palavras)
        {
            jogo.dicas = new string[10];
            jogo.contaDicas = 0;
            int D;

            for (int i = 0; i < linhas.Length; i++)
            {
                if (linhas[i].Substring(2) == jogo.palavras[numeroSorteado])
                {
                    for (int j = i + 1; j < i + 11; j++)
                    {
                        D = linhas[j].IndexOf('D');

                        if (D == 0 && linhas[j].Substring(2) != "")
                        {
                            jogo.dicas[jogo.contaDicas] = linhas[j].Substring(2);
                            jogo.contaDicas++;
                        }
                        else
                            break;
                    }
                }
            }
            return jogo.dicas;
        }

        /// <summary>
        /// Mostra uma dica caso o usuário aperte a tecla F2
        /// </summary>
        /// <param name="apertouF2"></param>
        static void MostraDicas(int apertouF2)
        {
            Console.CursorLeft = 31;
            Console.CursorTop = 5;
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.WriteLine("Dicas:");
            Console.ForegroundColor = ConsoleColor.Yellow;

            if (apertouF2 >= 0)
            {
                for (int i = 0; i <= apertouF2; i++)
                {
                    Console.CursorLeft = 31;
                    Console.CursorTop = 6 + i;
                    Console.WriteLine(jogo.dicas[i]);
                }
            }
            Console.CursorLeft = 0;
            Console.CursorTop = 15;
        }

        /// <summary>
        /// Pergunta se o usuário deseja sair
        /// </summary>
        /// <returns> retorna a resposta "S" ou "N"</returns>
        static char DesejaSair()
        {
            do
            {
                Console.Write("   Deseja continuar? <s/n> -> ");
                resposta = Console.ReadKey().KeyChar;

                if (resposta.ToString().ToUpper() != "N" && resposta.ToString().ToUpper() != "S")
                {
                    Console.Clear();
                    Console.WriteLine("\n   Digite apenas 's' ou 'n'");
                }
            }
            while (resposta.ToString().ToUpper() != "N" && resposta.ToString().ToUpper() != "S");

            return resposta;
        }

        /// <summary>
        /// Mostra se o usuário ganhou ou perdeu
        /// </summary>
        /// <param name="erros"> quantidade de erros </param>
        /// <param name="acertos"> quantidade de acertos (completar a palavra) </param>
        /// <param name="apertouF2"> quantidade de vezes que o usuário apertou a tecla F2 </param>
        static void GanhouOuPerdeu(int erros, int acertos, int apertouF2)
        {
            if (acertos == palavraSorteada.Replace(" ", "").Length)
            {
                Console.Clear();
                Console.WriteLine("\tVocê venceu!!!");
                Console.WriteLine("   A palavra era: " + palavraSorteada);
            }

            if (erros + apertouF2 == 6)
            {
                Console.Clear();
                Console.WriteLine("\tVocê perdeu!!!");
                Console.WriteLine("   A palavra era: " + palavraSorteada);
            }
        }

        /// <summary>
        /// Desenho da forca de acordo com os erros ou teclas F2 apertadas
        /// </summary>
        /// <param name="erros"> quantidade de erros</param>
        /// <param name="apertouF2"> quantidade de vezes que a tecla F2 foi apertada </param>
        static void DesenhoForca(int erros, int apertouF2)
        {
            if (erros + apertouF2 == 0)
            {
                Console.Write("________________\n" +
                              "|              |\n" +
                              "|              |\n" +
                              "|\n" +
                              "|\n" +
                              "|\n" +
                              "|\n" +
                              "|\n" +
                              "|\n" +
                              "|\n" +
                              "|\n" +
                              "|\n" +
                              "|\n" +
                              "|\t");
            }

            else if (erros + apertouF2 == 1)
            {
                Console.Write("________________\n" +
                              "|              |\n" +
                              "|              |\n" +
                              "|              O\n" +
                              "|\n" +
                              "|\n" +
                              "|\n" +
                              "|\n" +
                              "|\n" +
                              "|\n" +
                              "|\n" +
                              "|\n" +
                              "|\n" +
                              "|\t");
            }
            else if (erros + apertouF2 == 2)
            {
                Console.Write("________________\n" +
                              "|              |\n" +
                              "|              |\n" +
                              "|              O\n" +
                              "|              |\n" +
                              "|              |\n" +
                              "|              |\n" +
                              "|\n" +
                              "|\n" +
                              "|\n" +
                              "|\n" +
                              "|\n" +
                              "|\n" +
                              "|\t");
            }
            else if (erros + apertouF2 == 3)
            {
                Console.Write("________________\n" +
                              "|              |\n" +
                              "|              |\n" +
                              "|              O\n" +
                              "|           --[|\n" +
                              "|              |\n" +
                              "|              |\n" +
                              "|\n" +
                              "|\n" +
                              "|\n" +
                              "|\n" +
                              "|\n" +
                              "|\n" +
                              "|\t");
            }
            else if (erros + apertouF2 == 4)
            {
                Console.Write("________________\n" +
                              "|              |\n" +
                              "|              |\n" +
                              "|              O\n" +
                              "|           --[|]--\n" +
                              "|              |\n" +
                              "|              |\n" +
                              "|\n" +
                              "|\n" +
                              "|\n" +
                              "|\n" +
                              "|\n" +
                              "|\n" +
                              "|\t");
            }
            else if (erros + apertouF2 == 5)
            {
                Console.Write("________________\n" +
                              "|              |\n" +
                              "|              |\n" +
                              "|              O\n" +
                              "|           --[|]--\n" +
                              "|              |\n" +
                              "|              |\n" +
                              "|             [\n" +
                              "|             |\n" +
                              "|\n" +
                              "|\n" +
                              "|\n" +
                              "|\n" +
                              "|\t");
            }
        }

        /// <summary>
        /// Mostra quando todas as palavras já foram jogadas
        /// </summary>
        /// <returns> retorna o que o usuário digitar </returns>
        static char AcabouAsPalavras()
        {
            Console.WriteLine("Você já jogou com todas as palavras. Parabéns!!!");
            Console.Write("Pressione qualquer tecla para sair");
            acabou = Console.ReadKey().KeyChar;
            return acabou;
        }

        static void Main(string[] args)
        {
            string[] linhas = File.ReadAllLines("jogo.txt", Encoding.Default);

            ArmazenaPalavras(linhas);

            Console.WindowHeight = 30;

            Inicio();
            Nota();

            Random x = new Random();
            numerosSorteados = new int[jogo.contaPalavras];
            bool numeroNaoSorteado;
            int contaNumeros = 0;

            do
            {
                do
                {
                    numeroSorteado = x.Next(0, jogo.contaPalavras);
                    numeroNaoSorteado = true;

                    for (int i = 0; i < jogo.contaPalavras; i++)
                    {
                        if (numeroSorteado == numerosSorteados[i])
                        {
                            numeroNaoSorteado = false;
                            break;
                        }
                    }
                }
                while (numeroNaoSorteado == false);

                numerosSorteados[contaNumeros] = numeroSorteado;
                contaNumeros++;

                palavraSorteada = jogo.palavras[numeroSorteado].ToUpper();
                ArmazenaDicas(numeroSorteado, linhas, jogo.palavras);

                erros = 0;
                acertos = 0;
                apertouF2 = 0;
                tentativas = 0;
                string[] tracos = new string[palavraSorteada.Length];
                string[] letrasTestadas = new string[36];                

                for (int i = 0; i < tracos.Length; i++)
                {
                    if (palavraSorteada[i] == ' ')
                        tracos[i] = "  ";
                    else
                        tracos[i] = "_";
                }

                do
                {
                    Console.Clear();
                    Console.WriteLine("Pressione F2 para receber uma dica\n");
                    DesenhoForca(erros, apertouF2);

                    for (int i = 0; i < tracos.Length; i++)
                    {
                        Console.Write(tracos[i] + " ");
                    }

                    MostraDicas(apertouF2);

                    Console.Write("\n\n Letras já tentadas: ");
                    for (int i = 0; i < letrasTestadas.Length; i++)
                    {
                        Console.Write(letrasTestadas[i] + " ");
                    }

                    ConsoleKeyInfo tecla;
                    do
                    {
                        Console.CursorTop = 17;
                        Console.Write("\n\n Digite uma letra: ");
                        tecla = Console.ReadKey();
                    }
                    while (tecla.Key != ConsoleKey.F2 && !char.IsLetter(tecla.KeyChar));

                    letraMaiuscula = tecla.KeyChar.ToString().ToUpper();

                    if (tecla.Key == ConsoleKey.F2)
                        apertouF2++;
                    else
                    {
                        bool letraExiste = false;
                        bool letraJaDigitada = false;

                        for (int i = 0; i < letrasTestadas.Length; i++)
                        {
                            if (letraMaiuscula != letrasTestadas[i])
                                letraJaDigitada = false;
                            else
                            {
                                letraJaDigitada = true;
                                break;
                            }

                        }

                        if (letraJaDigitada == true)
                            erros++;

                        else
                        {
                            letrasTestadas[tentativas] = tecla.KeyChar.ToString().ToUpper();
                            tentativas++;

                            for (int i = 0; i < palavraSorteada.Length; i++)
                            {
                                if (Convert.ToChar(letraMaiuscula) == palavraSorteada[i])
                                {
                                    tracos[i] = letraMaiuscula;
                                    acertos++;
                                    letraExiste = true;
                                }
                            }

                            if (letraExiste == false)
                                erros++;
                        }
                    }
                                        
                    if (erros + apertouF2 == 6)
                    {
                        Console.Clear();
                        Console.Write("________________\n" +
                                      "|              |\n" +
                                      "|              |\n" +
                                      "|              O\n" +
                                      "|           --[|]--\n" +
                                      "|              |\n" +
                                      "|              |\n" +
                                      "|             [ ]\n" +
                                      "|             | |\n" +
                                      "|\n" +
                                      "|\n" +
                                      "|\n" +
                                      "|\n" +
                                      "|\t");
                        Thread.Sleep(2000);
                        Console.Clear();
                    }
                }
                while (erros + apertouF2 != 6 && acertos < palavraSorteada.Replace(" ", "").Length);

                GanhouOuPerdeu(erros, acertos, apertouF2);

                if (contaNumeros == numerosSorteados.Length)
                    AcabouAsPalavras();
                else
                    DesejaSair();
            }
            while (resposta.ToString().ToUpper() != "N" && acabou.ToString() != "");
        }
    }
}
