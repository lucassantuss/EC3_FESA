﻿using System;
using System.Text;
using System.IO;
using System.Threading;
using System.Media;

namespace Jogo_da_Forca_v1._0
{
    class Program
    {
        static int Temporestante = 120;
        static bool reinicia = true;
        static bool fechacronometro = false;
        static bool cronometrofinalizado = false;
        struct Dados
        {
            public string Palavra;
            public string[] Dicas;
        }
        static int SorteioMetodo(int numpalavras, int contasorteios, int[] numerosorteados)
        {
            int psorteio;//Esse método tem o objetivo de sortear a palavra e não permirtir que ela repita ate todas palavras forem sorteadas. 
            bool confererepetição;
            if (numerosorteados.Length == numpalavras)
            {
                for (int y = 0; y < numerosorteados.Length; y++)//Esse trecho com o If faz a leitura que se todas palavras ja foram usadas ele limpa o vetor
                    numerosorteados[y] = Convert.ToInt32(null);//para que possa repitir as palavras situadas no jogo.txt.
            }
            do
            {
                confererepetição = true;
                Random gerador = new Random();
                psorteio = gerador.Next(0, numpalavras);//Esse trecho é responsavel por fazer o sorteio das palavras e também não permitir que elas repitam.
                numerosorteados[contasorteios] = psorteio;
                if (contasorteios != 0)
                {
                    for (int r = 0; r < contasorteios; r++)
                    {
                        if (psorteio == numerosorteados[r])
                            confererepetição = false;
                    }
                }
            }
            while (confererepetição == false);
            return psorteio;
        }
        static void PiscaTelaVermelho()
        {
            for (int p = 0; p < 3; p++)//Esse metodo faz uma simples animação piscando a tela de vermelho.
            {
                Console.BackgroundColor = ConsoleColor.Red;//Ele pinta a tela depois o thread.sleep faz com que ela fique por 0,1 seg,
                Console.Clear();                           //intercalando as cores do fundo do console.
                Thread.Sleep(100);
                Console.BackgroundColor = ConsoleColor.Black;
                Console.Clear();
                Thread.Sleep(100);
            }
        }
        static void PintaVermelho(string texto)
        {
            ConsoleColor cor = Console.ForegroundColor;//Esse metodo pinta as letras de vermelho,
            Console.ForegroundColor = ConsoleColor.Red;//onde ele pega a cor do fundo e pinta de vermelho,
            Console.Write(texto);                      //ai ele volta para a cor padrão e deixa os caracteres vermelhos.
            Console.ForegroundColor = cor;
        }
        static void PintaVerde(string texto)
        {
            ConsoleColor cor = Console.ForegroundColor;  //Esse metodo pinta as letras de verde,
            Console.ForegroundColor = ConsoleColor.Green;//onde ele pega a cor do fundo e pinta de verde,
            Console.Write(texto);                        //ai ele volta para a cor padrão e deixa os caracteres verdes.
            Console.ForegroundColor = cor;
        }
        static void PintaAmarelo(string texto)
        {
            ConsoleColor cor = Console.ForegroundColor;   //Esse metodo pinta as letras de amarelo,
            Console.ForegroundColor = ConsoleColor.Yellow;//onde ele pega a cor do fundo e pinta de amarelo,
            Console.Write(texto);                         //ai ele volta para a cor padrão e deixa os caracteres amarelos.
            Console.ForegroundColor = cor;
        }
        static void ConfereCharJogarNovamente()
        {
            bool falhareinicia;//Esse método verifica se o usuário quer jogar novamente ou não,com controle de excessão.
            do
            {
                falhareinicia = true;
                try
                {
                    Console.SetCursorPosition(0, 4);
                    Console.Write("\nDeseja jogar novamente? <s/n>:    ");
                    Console.SetCursorPosition(31, 5);
                    ConsoleKeyInfo resposta = Console.ReadKey();
                    char resp = Convert.ToChar(resposta.Key.ToString().ToLower());
                    if (resp == 'n')
                    {
                        reinicia = true;
                        falhareinicia = false;
                    }
                    else if (resp == 's')
                    {
                        reinicia = false;
                        falhareinicia = false;
                    }
                }
                catch
                {
                    PintaVermelho("\nDigite somente as letras s e n!\n");
                }
            }
            while (falhareinicia == true);
        }
        static void CronometroMetodo(object o)
        {

            int Tempototal = 120;                             //Esse método é o utilizado pelo timer para fazer o controle do tempo.
            if (Temporestante == 0 || fechacronometro == true)//Esse faz o controle para que quando o jogo acabe o metodo pare de escrever na tela.
                cronometrofinalizado = false;
            if (Temporestante > 0 && cronometrofinalizado == true)//Esse trecho é a parte onde faz o decrécimo do tempo e escreve na tela.
            {
                Console.SetCursorPosition(0, 0);
                PintaAmarelo("Dicas: <F2>");
                Console.SetCursorPosition(58, 0);
                PintaVermelho("Tempo restante: ");
                if (Temporestante >= 10 && Temporestante < 100)
                    Console.Write("0");
                if (Temporestante >= 0 && Temporestante < 10)
                    Console.Write("00");
                Console.WriteLine(Temporestante + "seg");
                Console.SetCursorPosition(18, 14);
                Temporestante--;
            }
            if (cronometrofinalizado == false)//Esse if faz com que caso o jogador queira jogar denovo, pois irá resetar o tempo.
                Temporestante = Tempototal;
        }
        static void DesenhaCaixaDicas()
        {
            Console.SetCursorPosition(32, 12);//Esse metodo serve para "desenhar" um campo de dicas usando o posicionamento
            Console.WriteLine("________________________________________________");//do cursor em diferente posições.
            for (int y = 0; y < 11; y++)
            {
                Console.SetCursorPosition(31, 13 + y);
                Console.WriteLine("|");
            }
            Console.SetCursorPosition(32, 13);
            PintaAmarelo("Dicas:");
        }
        static int DesenhaBoneco(StringBuilder desenhoforca1, int[] vidas_acertos, int contaboneco)
        {
            if (vidas_acertos[0] == 5 && contaboneco == 0)//Esse metodo "desenha" uma parte do boneco cada vez que o úsuário erra,
            {                                             //Usando o remove e o insert, é tirado e colocado em uma certa posição as partes.
                desenhoforca1.Remove(33, 1);
                desenhoforca1.Insert(34, "O");
                contaboneco++;
            }
            else if (vidas_acertos[0] == 4 && contaboneco == 1)
            {
                desenhoforca1.Remove(58, 1);
                desenhoforca1.Insert(58, "|");
                contaboneco++;
            }
            else if (vidas_acertos[0] == 3 && contaboneco == 2)
            {
                desenhoforca1.Remove(81, 1);
                desenhoforca1.Insert(81, "/");
                contaboneco++;
            }
            else if (vidas_acertos[0] == 2 && contaboneco == 3)
            {
                desenhoforca1.Remove(83, 1);
                desenhoforca1.Insert(83, "\\");
                contaboneco++;
            }
            else if (vidas_acertos[0] == 1 && contaboneco == 4)
            {
                desenhoforca1.Remove(57, 1);
                desenhoforca1.Insert(57, "/");
                contaboneco++;
            }
            else if (vidas_acertos[0] == 0 && contaboneco == 5)
            {
                desenhoforca1.Remove(59, 1);
                desenhoforca1.Insert(59, "\\");
                contaboneco++;
            }
            return contaboneco;
        }
        static void ConfereLetra(char[] letras, int cont, ConsoleKeyInfo letra)
        {
            bool loop = false;//Esse método faz validação da letra que o usuário inserir.
            do              
            {
                try
                {                                                                 //primeiramente ele converte o key para char
                    letras[cont] = Convert.ToChar(letra.Key.ToString().ToUpper());//colocando ele em um vetor de char.
                    for (int o = 0; o < cont; o++)
                    {
                        if (letras[o] == letras[cont])//Essa parte verifica se a letra inserida ja foi digitada.
                        {
                            do
                            {
                                Console.SetCursorPosition(0, 13);
                                Console.Write("\nInsira um dígito:     ");
                                PintaVermelho("\nEsse dígito ja foi inserido!  ");//Caso ele ja tenha digitado, é feito o pedido novamente com um aviso.
                                letra = Console.ReadKey();
                                letras[cont] = Convert.ToChar(letra.Key.ToString().ToUpper());

                            }
                            while (letras[o] == letras[cont]);
                        }
                    }
                    loop = true;
                }
                catch//Caso o usuário digite algum caracter invalido esse controle de excessão atua na situação.
                {
                    Console.SetCursorPosition(0, 13);
                    Console.Write("\nDigite um dígito:    ");
                    PintaVermelho("\nDigite um dígito válido!          ");
                    letra = Console.ReadKey();
                }
            }
            while (loop == false);//Esse while sé será passado caso o usuário digite um caracter válido e não repitido
        }
        static int[] RemoveReplaceLetra(char[] letras, int cont, ConsoleKeyInfo letra, string[] palavrasseparadas, StringBuilder underlines, int[] vidas_acertos)
        {
            int contletra = 0;
            int repeteletra = 0;
            for (int i = 0; i < palavrasseparadas.Length; i++)//Esse método verifica todas as letras da(s) palavra(s), caso ele insire uma que
            {                                                 //a palavra possui ele ganha um ponto e uma vida que será descrescentada posteriormente.
                for (int k = 0; k < palavrasseparadas[i].Length; k++)
                {
                    if (palavrasseparadas[i][k] == letras[cont])
                    {
                        underlines.Remove(contletra * 2 + i, 1);//Esse trecho o remove tira o underline e troca pelo dígito inserido caso ele acerte.
                        underlines.Insert(contletra * 2 + i, letras[cont]);
                        vidas_acertos[1]++;
                        vidas_acertos[0]++;
                        if (repeteletra > 0)//Esse if serve para o usuário não ganhar mais de uma vida caso tenho mais de um dígito igual na palavra. 
                            vidas_acertos[0]--;
                        repeteletra++;
                    }
                    contletra++;
                }
            }
            return vidas_acertos;//Aqui o método retorna a quantidade de vida e acertos por meio de um vetor.
        }       
        static void Main(string[] args)
        {           
            
            Console.WriteLine("Desenvolvedores:\nRodrigo C. - 081170031\nJonatas J. - " +
                              "081170035\n\nJOGO [X]\nDICAS [X]\nCONTROLADOR DE TEMPO [X]\n\n"+
                              "Instruções:\n1-Caso o tempo acabe, você irá perder\n2-Para" +
                              " pedir uma dica aperte F2, porém irá perder uma vida.\n3-É " +
                              "desconsiderado acentuação nas palavras.\n4-Você" +
                              " possui 6 vidas.\n\nBoa Sorte!\n\nPressione Enter para continuar...");
            Console.ReadLine();
            Console.Clear();
            string[] palavrasedicas = File.ReadAllLines("jogo.txt", Encoding.Default);
            int q = 0;
            int contador = 0;
            int numpalavras = 0;
            int contasorteios = 0;
            int[] numerosorteados = new int[10];
            Dados[] vetor = new Dados[100];
            for (int p = 0; p < palavrasedicas.Length; p++)
            {
                if (palavrasedicas[p][0] == 'P')
                {
                    if (p != 0)
                        contador++;
                    vetor[contador].Palavra = palavrasedicas[p].ToUpper().Substring(2);
                    vetor[contador].Dicas = new string[10];
                    q = 0;
                    numpalavras++;
                }
                else if (palavrasedicas[p][0] == 'D')
                {
                    vetor[contador].Dicas[q] = palavrasedicas[p].Substring(2);
                    q++;
                }
            }
            Timer Cronometro = new Timer(CronometroMetodo, null, 10, 1000);
            do
            {
                int sorteio;                
                reinicia = true;
                sorteio = SorteioMetodo(numpalavras,contasorteios,numerosorteados);
                contasorteios++;
                if (numpalavras == contasorteios)
                    contasorteios = 0;                
                string desenhoforca = " _______________ \n|                      \n|                      \n|                      \n|\n|\n";
                string palavraunder = "";
                for (int i = 0; i < vetor[sorteio].Palavra.Length; i++)
                {
                    if (vetor[sorteio].Palavra[i] == ' ')
                        palavraunder += " ";
                    if (vetor[sorteio].Palavra[i] != ' ')
                        palavraunder += " _";
                }
                palavraunder = palavraunder.Trim();
                int cont = 0;
                int[] vidas_acertos = new int[2];
                vidas_acertos[0] = 6;
                vidas_acertos[1] = 0;
                int contdicas = 0;
                int contaboneco = 0;
                fechacronometro = false;
                cronometrofinalizado = true;
                char[] letras = new char[100];
                string[] palavrasseparadas = vetor[sorteio].Palavra.Split();
                StringBuilder desenhoforca1 = new StringBuilder(desenhoforca);
                StringBuilder underlines = new StringBuilder(palavraunder);
                string palavrasemespaco = vetor[sorteio].Palavra.Replace(" ", "");
                do
                {
                    Console.WriteLine("\n-------------------------------- Jogo Da Forca --------------------------------");
                    Console.Write(desenhoforca1);
                    Console.Write("Palavra: " + underlines);
                    PintaVermelho("\nVidas:");
                    Console.Write(vidas_acertos[0]);
                    Console.Write("\nLetras já digitadas: ");
                    for (int k = 0; k < cont; k++)
                    {
                        if (k != 0)
                            Console.Write("-");
                        Console.Write(letras[k]);
                    }
                    PintaVerde("\nAcertos: ");
                    Console.Write(vidas_acertos[1] + "-" + palavrasemespaco.Length);

                    for (int p = 0; p <= contdicas; p++)
                    {
                        Console.SetCursorPosition(32, 14 + p);
                        Console.Write(p + 1 + "-" + vetor[sorteio].Dicas[p]);
                    }
                    Console.SetCursorPosition(0, 13);
                    Console.WriteLine("\nDigite uma letra: ");
                    DesenhaCaixaDicas();

                    ConsoleKeyInfo letra = Console.ReadKey();
                    if (letra.Key.ToString() == "F2" && contdicas < q-1)
                    {
                        contdicas++;
                        for (int u = 0; u <= contdicas; u++)
                        {
                            Console.SetCursorPosition(32, 19 + u);
                            Console.Write(u + 1 + "-" + vetor[sorteio].Dicas[u]);
                        }
                        cont--;
                    }
                    else if (letra.Key.ToString() != "F2" || contdicas == q-1)
                    {
                        ConfereLetra(letras, cont, letra);
                        RemoveReplaceLetra(letras, cont, letra, palavrasseparadas, underlines, vidas_acertos);                        
                    }
                    cont++;
                    vidas_acertos[0]--;
                    contaboneco = DesenhaBoneco(desenhoforca1, vidas_acertos, contaboneco);
                    Console.Clear();
                }
                while (vidas_acertos[0] > 0 && vidas_acertos[1] < palavrasemespaco.Length && cronometrofinalizado == true);
                fechacronometro = true;
                if (vidas_acertos[0] <= 0 || cronometrofinalizado == false)
                {
                    PiscaTelaVermelho();
                    Console.Clear();
                    Console.WriteLine("\n------------------------------- Você Perdeu! :( --------------------------------");
                    Console.WriteLine("A palavra era: {0}", vetor[sorteio].Palavra);
                    ConfereCharJogarNovamente();
                }
                else if (vidas_acertos[1] >= palavrasemespaco.Length)
                {
                    Console.Clear();
                    Console.WriteLine("\n------------------------------- Você Ganhou !!! -------------------------------- ");
                    Console.WriteLine("A palavra era: {0}", vetor[sorteio].Palavra);
                    ConfereCharJogarNovamente();
                }
                Console.Clear();
            }
            while (reinicia == false);
        }

    }
}
