﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Text;

namespace JogoDaForca1a

    static void Main(string[] args)
    {

        Console.ForegroundColor = ConsoleColor.Green; Console.WriteLine(" **************** JOGO DA FORCA ********************");
        Console.WriteLine(" Aluno: Samuel Ícaro Rocha - RA: 081170040");

         Console.WriteLine(" DICAS[X]");
         Console.WriteLine(" JOGO [X]");

    class Program
    {
        public static double temposegundos = 0;
        public static bool jogo = true;
        public static int cont = 0;
        public static int seg = 180;
       
        struct adivinha
      
        {

            public string questoes;
            public string[] dicas;
         
        }
        int vidas = 10;

        adivinha[,] palavra = new adivinha[100, 5];
        static string[] dicas()
        {
            string dicas = new string [];
        }
        static void Main(string[] args)
        {

            
            static int LeituraPalavras(adivinha[,] palavras)  /* metodo para ler palavras */
            {



                int i = 0, j = 0;
                if (File.Exists("Jogo.Txt"))
                {

                    string palavras = File.ReadAllText("jogo.txt");
                    if (palavras[0] == " P")
                    {
                        if (j > 0)
                        {
                            j = 0;

                            i++;
                        }

                        palavras[1, 0].perguntas = palavras;

                    }
                    if (palavras[0] == "D")
                    {
                        palavras[i, j].dicas = palavras;
                        j++;
                    }
                    palavras[i, 0].qntDicas = j;


                }
            string[] linhas =
            File.ReadAllLines("forca.txt"); 

         
            string palavra = "  ", letra = "  ";
            int erros = 0, completo = 0, posicao = 0;
            

            bool sair = false;
            const int limite = 7;
            Random rnd = new Random();

            int escolha = rnd.Next(0, 6);
            palavra = palavras[escolha];
            string[] quebrada = new string[palavra.Length];

            while (!sair)
            {
                Console.Clear();
                Console.WriteLine(" Erros: {0} de {1}", erros, limite);

                if (erros == 1)
                  

                for (int i = 0; i < quebrada.Length; i++)
                {
                    if (quebrada[i] != null)
                    {
                        Console.WriteLine(quebrada[i] + "     ");
                    }

                }

                bool crt;
                do
                {
                    try
                    {


                        Console.WriteLine("\n Escolha a Posição da Letra!");
                        posicao = int.Parse(Console.ReadLine());
                        crt = true;
                    }
                    catch
                    {
                        crt = false;
                        Console.WriteLine("DIGITE SOMENTE NUMEROS !!");
                        
                        
                    }

                } while (crt == false);
                 



                bool correto;

                do

                {



                    try
                    {


                        Console.WriteLine("Digite a letra !");
                        letra = Console.ReadLine();
                        correto = true;
                    }

                    catch
                    {
                        correto = false;
                        Console.WriteLine("DIGITE SOMENTE LETRAS !!");
                        

                    }
                }
                while (correto == false);
                    if (palavra.ElementAt(posicao - 1) == letra.ElementAt(0))
                    {
                        quebrada[posicao = 1] = letra;
                        completo++;
                    }
                    else
                    {
                        erros++;
                    }
                    if (erros >= limite)
                    {
                        sair = true;
                    }
                    if (completo == palavra.Length)
                    {
                        sair = true;
                    }


                if (completo == palavra.Length)
                {
                    Console.Clear();
                    Console.WriteLine(" Parabéns! a palavra era: {0}", palavra);
                }
                else if (erros == limite)
                {
                    Console.Clear();
                    Console.WriteLine(" Errou 7 vezes! Enforcado   |");
                    Console.WriteLine();

                }
                    Console.ReadKey();

            }

        }
    }

}


    



    

