﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Jogo_da_forca
{
    class Program
    {
        #region Variaveis Globais
        static PalavrasEDicas[] vetor = new PalavrasEDicas[100]; 
        static int[] palavrasSorteadas = new int[100];
        static int contPalavrasSorteadas = -1;
        static int contVidas;
        static bool gameOver = false;
        static int palavrasTotais = 0;
        static char acabouSimOuNao;
        #endregion

        #region PROCESSAMENTO
        /// <summary>
        /// Reinicia todas as palavras igualando-as a "false", ou seja, ñão utilizada.
        /// </summary>
        static void ReiniciaPalavras()
        {
            for (int n = 0; n == palavrasTotais; n++) 
                vetor[n].sorteio = false;
        }

        /// <summary>
        /// Caso o número de palavras seja igual a quantidadede palavras sorteadas, 
        /// uma pergunta é printada: "Deseja resetar as palavras?". Caso seja "true"
        /// o jogo é resetado.
        /// </summary>
        /// <param name="numeroPalavras"></param>
        /// <returns>Retorna para Main um resposta booleana, se o jogo acabou ou nao.</returns>
        static bool PalavrasEsgotadas()
        {
            bool jogoAcabou = false;
            bool exceçao = false;


            if (contPalavrasSorteadas == palavrasTotais)
            {
                do
                {
                    Console.CursorLeft = 0;
                    Console.CursorTop = 2;
                    Console.Write("Deseja resetar as palavras ? <s/n>");
                    char sOUn = Console.ReadLine().ToUpper()[0];
                    try
                    {
                        if (sOUn == 'S')
                        {
                            exceçao = false;
                            acabouSimOuNao = 'S';
                        }
                        else if (sOUn == 'N')
                        {
                            exceçao = false;
                            acabouSimOuNao = 'N';
                        }
                        else
                        {
                            Console.CursorLeft = 0;
                            Console.CursorTop = 3;
                            Console.Write("                                                   ");

                            Console.CursorLeft = 0;
                            Console.CursorTop = 3;
                            Console.Write("Digite somente s / n !");
                            exceçao = true;
                        }
                    }
                    catch
                    {
                        Console.Write("Digite somente letras :)");
                        exceçao = true;
                        Console.CursorLeft = 0;
                        Console.CursorTop = 3;
                    }
                } while (exceçao);
            }
            return jogoAcabou;
        }

        /// <summary> 
        /// Após o termino do tempo ou quando o usuario consegue descobrir a palavra sorteada,
        /// é printada na tela um pergunta se ele deseja continuar jogando.</summary>
        /// <returns>Após o usuário responder ele retorna um valor boleano para a função main.</returns>
        static bool DesejaContinuar()
        {
            bool resposta = false;
            bool exceçao = false;

            

            Console.CursorLeft = 0;
            Console.CursorTop = 2;
            do
            {
                try
                {
                    
                    Console.CursorLeft = 0;
                    Console.CursorTop = 2;
                    Console.Write("Deseja continuar jogando ? (S / N)");
                    char sOUn = Console.ReadLine().ToUpper()[0];
                    if (sOUn == 'S')
                    {
                        resposta = true;
                        exceçao = false;
                    }
                    else if (sOUn == 'N')
                    {
                        resposta = false;
                        exceçao = false;
                    }
                    else
                    {
                        Console.CursorLeft = 0;
                        Console.CursorTop = 3;
                        Console.Write("                                                   ");

                        Console.CursorLeft = 0;
                        Console.CursorTop = 3;
                        Console.Write("Digite somente s / n !");
                        exceçao = true;
                    }
                }
                catch
                {
                    Console.Write("Digite somente letras");
                    exceçao = true;
                }
            } while (exceçao);
            return resposta;
        }

        /// <summary>
        /// Método principal do programa, onde são feitas todas as verificações sobre a letra digitada pelo usuário
        /// e as possíveis exceções.
        /// </summary>
        /// <param name="numeroPalavras">Recebe o número sorteado.</param>
        /// <returns>Caso o tempo limite termine ou as palavra sorteada for acertada, o programa retorna um valor
        /// bool para que a Main faça a verificação se o usuário deseja continuar jogando.</returns>
        static bool RecebeLetras(int numeroPalavras)
        {
        
            #region Variaveis
            DateTime inicio = DateTime.Now;

            bool flag = false;
            bool letraRepetida = false;
            bool verificao = false;
            bool eUmaLetra = false;

            string palavraJogo = vetor[numeroPalavras].palavras;
            string[] letrasDigitadas = new string[vetor[numeroPalavras].palavras.Length];
            string[] letrasErradas = new string[26 - vetor[numeroPalavras].palavras.Length];
            string verificaLetra = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

            int contador = 0;
            int contLetra = 0;
            int numeroDicas = 1;
            int posicaoLetrasErradas = 0;
            int posicaoLetrasDigitadas = 0;

            double tempoDecorrido = 0;
            #endregion

            do
            {
                if (contVidas == 0)
                    break;
                Console.CursorLeft = 1;
                Console.CursorTop = 10;
                Console.Write("Digite uma letra:");

                if (Console.KeyAvailable)
                {
                    contLetra = 0;
                    ConsoleKeyInfo tecla = Console.ReadKey();
                    string letra = tecla.Key.ToString();

                    for (int j = 0; j < verificaLetra.Length; j++)
                    {
                        if (Convert.ToString(verificaLetra[j]) == letra || letra == "F2")
                            contLetra++;
                    }

                    eUmaLetra = (contLetra != 0);

                    try
                    {
                        if (eUmaLetra) // Não entra se for caracteres especiais
                        {
                            for (int n = 0; n < palavraJogo.Length; n++) 
                            {
                                letraRepetida = false;

                                if (letra.ToString() == "F2") // Caso for uma dica
                                {
                                    numeroDicas++;
                                    if (numeroDicas <= vetor[numeroPalavras].qntdDicas)
                                    {
                                        Console.CursorLeft = 52;
                                        Console.CursorTop = 7;
                                        Console.Write("                                           ");

                                        Thread.Sleep(500);

                                        Console.CursorLeft = 52;
                                        Console.CursorTop = 7;
                                        Console.Write("{0}", vetor[numeroPalavras].dicas[numeroDicas - 1]);

                                        Console.CursorLeft = 0;
                                        Console.CursorTop = 12;

                                        Console.Write(Vidas(--contVidas));

                                        break;
                                    }
                                    else // Se as dicas acabarem
                                    {
                                        Console.CursorLeft = 52;
                                        Console.CursorTop = 7;
                                        Console.Write("Você não tem mais dicas disponíveis !");
                                        break;
                                    }
                                }
                                //--------------------------------------------------//

                                if (verificao && letra.ToString() != "F2")
                                {
                                    for (int k = 0; k < palavraJogo.Length; k++)
                                    {
                                        if (letrasDigitadas[k] == letra)
                                            letraRepetida = true;
                                    }

                                    if (!letraRepetida)
                                        verificao = false;
                                }
                                //--------------------------------------------------//

                                if (!letraRepetida)
                                {
                                    if (letra == palavraJogo[n].ToString() && letra != "F2")
                                    {
                                        Console.CursorLeft = (n * 2) + 1;
                                        Console.CursorTop = 7;
                                        letrasDigitadas[posicaoLetrasDigitadas] = letra;
                                        Console.Write(letra);

                                        Console.CursorLeft = 1;
                                        Console.CursorTop = 17;
                                        Console.Write("                    ");

                                        contador++;
                                        posicaoLetrasDigitadas++;
                                    }
                                }
                                else
                                {
                                    Console.CursorLeft = 1;
                                    Console.CursorTop = 17;
                                    Console.Write("Letra repetida");

                                    Console.CursorLeft = 0;
                                    Console.CursorTop = 12;

                                    Console.Write(Vidas(--contVidas));

                                    break;
                                }
                                //--------------------------------------------------//

                                if (n == palavraJogo.Length - 1)
                                    verificao = true;
                                //--------------------------------------------------//

                                if (palavraJogo.IndexOf(letra.ToString()) == -1 && letra.ToString() != "F2" && verificao)
                                {
                                    Console.CursorLeft = 1;
                                    Console.CursorTop = 17;
                                    Console.Write("Letra errada!");

                                    Console.CursorLeft = 0;
                                    Console.CursorTop = 12;

                                    Console.Write(Vidas(--contVidas));

                                    letrasErradas[posicaoLetrasErradas] = letra;
                                    posicaoLetrasErradas++;

                                    Console.CursorLeft = 32;
                                    Console.CursorTop = 10;

                                    for (int k = 0; k <= posicaoLetrasErradas; k++)
                                        Console.Write("{0} ", letrasErradas[k]);
                                }
                                //--------------------------------------------------//
                            }
                            //--------------------------------------------------//
                        }
                        Thread.Sleep(500); // o processamento para. valor em milissegundos
                    }
                    //--------------------------------------------------//
                    catch
                    {
                        Console.CursorLeft = 1;
                        Console.CursorTop = 17;
                        Console.Write("Apenas letras amigo!");
                    }
                }
                Thread.Sleep(500);
                Console.CursorLeft = 41;
                Console.CursorTop = 19;
                tempoDecorrido = DateTime.Now.Subtract(inicio).TotalSeconds;

                Console.WriteLine("|  Ainda restam " + (60 - Math.Truncate(tempoDecorrido)) + "seg.  |");

                if (contador == vetor[numeroPalavras].palavras.Length && contPalavrasSorteadas == palavrasTotais)
                    return PalavrasEsgotadas();
                else if(contador == vetor[numeroPalavras].palavras.Length)
                    return !flag;
            }
            while (tempoDecorrido <= 60);

            if (contVidas != 0)
                OverTime();

            return !PalavrasEsgotadas();
        }

        /// <summary>
        /// Printa a palavra codificada e a sua primeira dica.
        /// </summary>
        /// <param name="numeroPalavras">Recebe o número sorteado</param>
        static void PalavraEDicaJogo(int numeroPalavras)
        {
            MenuVidas();
    
            Console.CursorLeft = 1;
            Console.CursorTop = 7;
            for (int i = 0; i < vetor[numeroPalavras].palavras.Length; i++)
            {
                Console.Write("_ ");
            }
            Console.CursorLeft = 52;
            Console.CursorTop = 7;
            Console.Write($"{vetor[numeroPalavras].dicas[0]}");
        }

        /// <summary>
        /// Recebo a tecla inicial para iniciar o jogo, neste caso a barra de espaço.
        /// </summary>
        static void Start()
        {
            bool flag = false;
            do
            {
                if (Console.KeyAvailable)
                {
                    ConsoleKeyInfo entrada = Console.ReadKey();
                    if (entrada.Key.ToString() == "Spacebar")
                    {
                        Console.Clear();
                        flag = true;
                    }
                    Thread.Sleep(500);
                }
            } while (!flag);
        }

        /// <summary>
        /// Sorteia um número de palavras aleátorio, sempre verificando se o número já foi sorteado.
        /// </summary>
        /// <param name="numeroPalavras">Recebe o número sorteado para verificação.</param>
        /// <returns>Após o término do sorteio o método devolve o numero sorteado para Main</returns>
        static int SorteiaPalavra()
        {
            Thread.Sleep(500);
            Random numberAleatorio= new Random();

            int palavraSorteada = numberAleatorio.Next(0, palavrasTotais+1);
            do
            {
                if (vetor[palavraSorteada].sorteio == false)
                {
                    vetor[palavraSorteada].sorteio = true;
                    Thread.Sleep(500);
                    contPalavrasSorteadas++;
                    return palavraSorteada;
                }
                else
                    palavraSorteada = numberAleatorio.Next(0, palavrasTotais + 1);
            } while (vetor[palavraSorteada].sorteio);

            return palavraSorteada;
        }

        /// <summary>
        /// Método destinado a leituda o arquivo txt, salvando no vetor global as
        /// palavras e as dicas sem os "P:" e "D:". Caso o arquivo não for encontrado
        /// é exibido uma mensagem de erro.
        /// </summary>
        /// <returns>Retorna quantidade de palavras encontradas no aquivo texto.</returns>
        static int LerArquivo()
        {
            int contPalavras = -1;
            int contDicas = 0;
            bool stringCriada = false;
            try
            {
                foreach (string line in File.ReadLines("jogo.txt", Encoding.Default)) //salva cada linha do arquivo em uma string line.
                {
                    if (line.Contains("P:")) // verifica se a string possui uma palavra.
                    {
                        contPalavras++;
                        vetor[contPalavras] = new PalavrasEDicas(); // cria um espaço na memória.
                        vetor[contPalavras].palavras = line.Substring(2, line.Length - 2).ToUpper(); //retira o"P:" e salva somente a palavra.

                        contDicas = 0;
                        stringCriada = false;
                    }
                    else if (line.Contains("D:")) // verifica se a string tem um dica.
                    {
                        if (!stringCriada && contDicas == 0) // Cria a string de dicas, apenas uma vez.
                        {
                            vetor[contPalavras].dicas = new string[10];
                            vetor[contPalavras].qntdDicas = new int();
                            vetor[contPalavras].qntdDicas = 0;
                            stringCriada = true;
                        }
                        vetor[contPalavras].dicas[contDicas] = line.Substring(2, line.Length - 2); // retira o "D:" e salva somente a dica.
                        vetor[contPalavras].qntdDicas++;
                        contDicas++;
                    }
                }
            }
            catch
            {
                Console.Write("Arquivo texto não encontrado :(");
                Thread.Sleep(5000);
                Environment.Exit(0);
            }
            return contPalavras;
        }

        #endregion

        #region ANIMACOES

        /// <summary>
        /// Informações inicias do aluno.
        /// </summary>
        static void Requisitos()
        {
            Console.SetWindowSize(80, 15);
            Console.CursorTop = 3;
            Console.Write(" ╔════════════════════════════════════════════════════════════════════╗\n" +
                          " ║                                                                    ║\n" +
                          " ║ ||   Jogo feito por: Thales Pereira de Jesus   RA: 081170033   ||  ║\n" +
                          " ║                                                                    ║\n" +
                          " ║                             JOGO [ X ]                             ║\n" +
                          " ║                             DICAS[ X ]                             ║\n" +
                          " ║                        CONTROLE DE TEMPO[ X ]                      ║\n" +
                          " ║                                                                    ║\n" +
                          " ╚════════════════════════════════════════════════════════════════════╝");
            Thread.Sleep(4000);
            Console.Clear();
        }

        /// <summary>
        /// Limpa a tela após as peguntas de continuação.
        /// </summary>
        static void LimpaTela()
        {
            Console.CursorLeft = 0;
            Console.CursorTop = 2;
            Console.Write("                                                                     \n" +
                          "                                                                     ");
        }

        /// <summary>
        /// Printa na tela OverTime assim que o tempo máximo é esgotado
        /// </summary>
        static void OverTime()
        {
            Console.CursorLeft = 0;
            Console.CursorTop = 9;
            Console.Write("" +
           "╔═════════════════════════════════════════════════════════════════════════════════════════════════════════╗   \n" +
           "╠═════════════════════════════════════════════════════════════════════════════════════════════════════════╣   \n" +
           "╠═════════════════════════════════════════════════════════════════════════════════════════════════════════╣   \n" +
           "║                                                                                                         ║   \n" +
           "║          ████████  ██      ██  ████████  ████████           ████████  ██  ██      ██  ████████          ║   \n" +
           "║          ██    ██  ██      ██  ██        ██    ██              ██     ██  ████  ████  ██                ║   \n" +
           "║          ██    ██  ██      ██  █████     ████████              ██     ██  ██  ██  ██  ██████            ║   \n" +
           "║          ██    ██    ██  ██    ██        ██   ██               ██     ██  ██      ██  ██                ║   \n" +
           "║          ████████      ██      ████████  ██    ██              ██     ██  ██      ██  ████████          ║   \n" +
           "╠═════════════════════╗╔═══════════════════════════════════════════════════════════╗╔═════════════════════╣   \n" +
           "║█████████████████████║║                        Game Over                          ║║█████████████████████║   \n" +
           "╚═════════════════════╝╚═══════════════════════════════════════════════════════════╝╚═════════════════════╝   \n");
        }

        /// <summary>
        /// Printa o menu principal do jogo, contendo as vidas máximas e os locais de dicas, 
        /// palavras e mensagens. 
        /// </summary>
        static void MenuVidas()
   {
       Console.CursorLeft = 0;
       Console.CursorTop = 6;
       Console.Write(
           "╔══════════════════════════════════════════╗╔══════╦══════════════════════════════════════════════════════╗\n" +
           "║                                          ║║ Dica ║                                                      ║\n" +
           "╚══════════════════════════════════════════╝╚══════╩══════════════════════════════════════════════════════╝\n" +
           "╔═══════════════════════════╗╔════════════════════════════════════════════════════════════════════════════╗\n" +
           "║                           ║║                                                                            ║\n" +
           "╠═══════════════════════════╝╚════════════════════════════════════════════════════════════════════════════╣\n" +
           "║  ██  ██  ██  ████    ██████     ███  ███       ███  ███       ███  ███       ███  ███       ███  ███    ║\n" +
           "║  ██  ██  ██  ██  ██  ██  ██   ██   ██   ██   ██   ██   ██   ██   ██   ██   ██   ██   ██   ██   ██   ██  ║\n" +
           "║  ██  ██  ██  ██  ██  ██████   ██        ██   ██        ██   ██        ██   ██        ██   ██        ██  ║\n" +
           "║    ██    ██  ████    ██  ██     ██    ██       ██    ██       ██    ██       ██    ██       ██    ██    ║\n" +
           "╠═════════════════════╗              ██             ██             ██             ██             ██       ║\n" +
           "║                     ║                                                                                   ║\n" +
           "╠═════════════════════╣╔═══════════════════════════════════════════════════════════╗╔═════════════════════╣\n" +
           "║█████████████████████║║                                                           ║║█████████████████████║\n" +
           "╚═════════════════════╝╚═══════════════════════════════════════════════════════════╝╚═════════════════════╝\n");
   }

        /// <summary>
        /// Printa a Tela inicial do "Jogo da forca"
        /// </summary>
        static void TelaInicial()
        {
            Console.Clear();
            Console.Write("                                                                          \n" +
                          "                                                                          \n" +
                          "                                                                          \n" +
                          "                                                                          \n" +
                          "     ███████     █████       █████       █████        ██████       █████  \n" +
                          "          ██   ██     ██   ██     ██   ██     ██      ██    ██   ██     ██\n" +
                          "          ██   ██     ██   ██          ██     ██      ██    ██   ██     ██\n" +
                          "          ██   ██     ██   ██   ████   ██     ██      ██    ██   █████████\n" +
                          "    ██    ██   ██     ██   ██     ██   ██     ██      ██    ██   ██     ██\n" +
                          "      ████       █████       █████       █████        ██████     ██     ██\n" +
                          "                                                                          \n" +
                          "                         █                                                \n" +
                          "                         █                                                \n" +
                          "                         █                                                \n" +
                          "         █████████      ███       ████████       ██████       █████       \n" +
                          "         ██             ███       ██      ██   ██      ██   ██     ██     \n" +
                          "         ██████         ███       ██      ██   ██           ██     ██     \n" +
                          "         ██           █ █ █ █     ████████     ██           █████████     \n" +
                          "         ██           █ █ █ █     ██     ██    ██      ██   ██     ██     \n" +
                          "         ██         ██       ██   ██      ██     ██████     ██     ██     \n" +
                          "                    ██       ██                                           \n" +
                          "                    ██       ██                                           \n" +
                          "                      ███████                                             \n" +
                          "                                                                          \n" +
                          "                            | Precione espaço |                           \n");
        }

        /// <summary>
        /// Printa na tela a quantidade atual de vida do usuário.
        /// </summary>
        /// <param name="numVidas">Quantidade int de vidas do usuário.</param>
        /// <returns>Retorna a quantidade de vida atual do usario de acordo com parametro
        /// após o parametro zera, o procimo erro do usuario acarretará em "Game Over"</returns>
        static string Vidas(int numVidas)
        {
            string[] vidas = new string[10];

            if (numVidas == 0)
                gameOver = true;

            vidas[0] =
                       "║  ██  ██  ██  ████    ██████                                                                             ║   \n" +
                       "║  ██  ██  ██  ██  ██  ██  ██                                                                             ║   \n" +
                       "║  ██  ██  ██  ██  ██  ██████                                                                             ║   \n" +
                       "║    ██    ██  ████    ██  ██                                                                             ║   \n";


            vidas[1] =
                       "║  ██  ██  ██  ████    ██████     ███                                                                     ║   \n" +
                       "║  ██  ██  ██  ██  ██  ██  ██   ██   █                                                                    ║   \n" +
                       "║  ██  ██  ██  ██  ██  ██████   ██                                                                        ║   \n" +
                       "║    ██    ██  ████    ██  ██     ██                                                                      ║   \n" +
                       "╠═════════════════════╗              █                                                                    ║   \n";

            vidas[2] =
                       "║  ██  ██  ██  ████    ██████     ███  ███                                                                ║   \n" +
                       "║  ██  ██  ██  ██  ██  ██  ██   ██   ██   ██                                                              ║   \n" +
                       "║  ██  ██  ██  ██  ██  ██████   ██        ██                                                              ║   \n" +
                       "║    ██    ██  ████    ██  ██     ██    ██                                                                ║   \n" +
                       "╠═════════════════════╗              ██                                                                   ║   \n";


            vidas[3] = 
                       "║  ██  ██  ██  ████    ██████     ███  ███       ███                                                      ║   \n" +
                       "║  ██  ██  ██  ██  ██  ██  ██   ██   ██   ██   ██   █                                                     ║   \n" +
                       "║  ██  ██  ██  ██  ██  ██████   ██        ██   ██                                                         ║   \n" +
                       "║    ██    ██  ████    ██  ██     ██    ██       ██                                                       ║   \n" +
                       "╠═════════════════════╗              ██             █                                                     ║   \n";


            vidas[4] =
                        "║  ██  ██  ██  ████    ██████     ███  ███       ███  ███                                                 ║   \n" +
                        "║  ██  ██  ██  ██  ██  ██  ██   ██   ██   ██   ██   ██   ██                                               ║   \n" +
                        "║  ██  ██  ██  ██  ██  ██████   ██        ██   ██        ██                                               ║   \n" +
                        "║    ██    ██  ████    ██  ██     ██    ██       ██    ██                                                 ║   \n" +
                        "╠═════════════════════╗              ██             ██                                                    ║   \n";


            vidas[5] =
                       "║  ██  ██  ██  ████    ██████     ███  ███       ███  ███       ███                                       ║   \n" +
                       "║  ██  ██  ██  ██  ██  ██  ██   ██   ██   ██   ██   ██   ██   ██   █                                      ║   \n" +
                       "║  ██  ██  ██  ██  ██  ██████   ██        ██   ██        ██   ██                                          ║   \n" +
                       "║    ██    ██  ████    ██  ██     ██    ██       ██    ██       ██                                        ║   \n" +
                       "╠═════════════════════╗              ██             ██             █                                      ║   \n";


            vidas[6] =
                       "║  ██  ██  ██  ████    ██████     ███  ███       ███  ███       ███  ███                                  ║   \n" +
                       "║  ██  ██  ██  ██  ██  ██  ██   ██   ██   ██   ██   ██   ██   ██   ██   ██                                ║   \n" +
                       "║  ██  ██  ██  ██  ██  ██████   ██        ██   ██        ██   ██        ██                                ║   \n" +
                       "║    ██    ██  ████    ██  ██     ██    ██       ██    ██       ██    ██                                  ║   \n" +
                       "╠═════════════════════╗              ██             ██             ██                                     ║   \n";


            vidas[7] =
                       "║  ██  ██  ██  ████    ██████     ███  ███       ███  ███       ███  ███       ███                        ║   \n" +
                       "║  ██  ██  ██  ██  ██  ██  ██   ██   ██   ██   ██   ██   ██   ██   ██   ██   ██   █                       ║   \n" +
                       "║  ██  ██  ██  ██  ██  ██████   ██        ██   ██        ██   ██        ██   ██                           ║   \n" +
                       "║    ██    ██  ████    ██  ██     ██    ██       ██    ██       ██    ██       ██                         ║   \n" +
                       "╠═════════════════════╗              ██             ██             ██             █                       ║   \n";


            vidas[8] =
                       "║  ██  ██  ██  ████    ██████     ███  ███       ███  ███       ███  ███       ███  ███                   ║   \n" +
                       "║  ██  ██  ██  ██  ██  ██  ██   ██   ██   ██   ██   ██   ██   ██   ██   ██   ██   ██   ██                 ║   \n" +
                       "║  ██  ██  ██  ██  ██  ██████   ██        ██   ██        ██   ██        ██   ██        ██                 ║   \n" +
                       "║    ██    ██  ████    ██  ██     ██    ██       ██    ██       ██    ██       ██    ██                   ║   \n" +
                       "╠═════════════════════╗              ██             ██             ██             ██                      ║   \n";


            vidas[9] =
                       "║  ██  ██  ██  ████    ██████     ███  ███       ███  ███       ███  ███       ███  ███       ███         ║   \n" +
                       "║  ██  ██  ██  ██  ██  ██  ██   ██   ██   ██   ██   ██   ██   ██   ██   ██   ██   ██   ██   ██   █        ║   \n" +
                       "║  ██  ██  ██  ██  ██  ██████   ██        ██   ██        ██   ██        ██   ██        ██   ██            ║   \n" +
                       "║    ██    ██  ████    ██  ██     ██    ██       ██    ██       ██    ██       ██    ██       ██          ║   \n" +
                       "╠═════════════════════╗              ██             ██             ██             ██             █        ║   \n";

            if (!gameOver)
                return vidas[numVidas];
            else
                return
                       "║              ████████  ████████  ██      ██  ████████   ████████  ██    ██  ████████  ████████          ║\n" +
                       "║              ██        ██    ██  ████  ████  ██         ██    ██  ██    ██  ██        ██    ██          ║\n" +
                       "║              ██        ████████  ██  ██  ██  ██████     ██    ██  ██    ██  ██████    ████████          ║\n" +
                       "║              ██    ██  ██    ██  ██      ██  ██         ██    ██  ██    ██  ██        ██   ██           ║\n" +
                       "║              ████████  ██    ██  ██      ██  ████████   ████████    ████    ████████  ██    ██          ║\n" +
                       "║                                                                                                         ║\n";
                       
        }
        #endregion

        struct PalavrasEDicas
        {
            public string palavras;
            public string[] dicas;
            public int qntdDicas;
            public bool sorteio;
        }

        static void Main(string[] args)
        {
            int numeroPalavras;
            bool resetar = false;
            bool simOuNao = false;

            Requisitos();
            
            do
            {
                contPalavrasSorteadas = -1;

                Console.CursorVisible = false;

                Console.SetWindowSize(80 , 30);
                TelaInicial();

                Start();

                Console.SetWindowSize(120, 30);
                numeroPalavras = LerArquivo();
                palavrasTotais = numeroPalavras;

                int numeroPalavrasRandom = SorteiaPalavra(); //Salva o número aleatório na variável.

                ReiniciaPalavras();

                do
                {
                    contVidas = 10; // Reinicia a vida do usúario.
                    gameOver = false; // Reinicia o estado do jogo.
                    simOuNao = false; //Reinicia a pergunta.
                    acabouSimOuNao = 'N';

                    LimpaTela();
                    PalavraEDicaJogo(numeroPalavrasRandom);

                    if (RecebeLetras(numeroPalavrasRandom) && acabouSimOuNao != 'S') // Caso a palavra foi acertada ou houve Overtime, realiza a pergunta se deseja continuar.
                    {
                        simOuNao = DesejaContinuar();
                        if (simOuNao)
                            numeroPalavrasRandom = SorteiaPalavra(); // Se for "sim" é sorteado uma nova palavra.
                    }
                    else if (acabouSimOuNao == 'S')
                        resetar = true;
                } while (simOuNao);

            } while (resetar && acabouSimOuNao != 'N');
        }
    }
}
